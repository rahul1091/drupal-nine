# Solvay Acidosis Calculator — Drupal Custom Module

## Overview

Multi-step webform calculator supporting **6 languages**: English (en), French (fr), Italian (it), Spanish (es), Dutch (nl), and German (de).

---

## Directory Structure

```
solvay_acidosis_calculator/
├── solvay_acidosis_calculator.info.yml
├── solvay_acidosis_calculator.module
├── solvay_acidosis_calculator.services.yml
├── solvay_acidosis_calculator.routing.yml
├── solvay_acidosis_calculator.libraries.yml
├── translations/
│   ├── solvay_acidosis_calculator.fr.po    ← French
│   ├── solvay_acidosis_calculator.it.po    ← Italian
│   ├── solvay_acidosis_calculator.es.po    ← Spanish
│   ├── solvay_acidosis_calculator.nl.po    ← Dutch
│   └── solvay_acidosis_calculator.de.po    ← German
├── config/
│   ├── webform.webform.solvay_acidosis_calculator.yml   ← English base
│   └── language/
│       ├── fr/webform.webform.solvay_acidosis_calculator.yml
│       ├── it/webform.webform.solvay_acidosis_calculator.yml
│       ├── es/webform.webform.solvay_acidosis_calculator.yml
│       ├── nl/webform.webform.solvay_acidosis_calculator.yml
│       └── de/webform.webform.solvay_acidosis_calculator.yml
├── src/
│   ├── Service/AcidosisCalculatorService.php
│   ├── Plugin/WebformHandler/AcidosisCalculatorHandler.php
│   └── Controller/AcidosisResultsController.php
├── templates/ruminal-acidosis-results.html.twig
├── css/
│   ├── ruminal-acidosis-calculator.css
│   └── ruminal-acidosis-results.css
└── js/
    ├── ruminal-acidosis-calculator.js
    └── ruminal-acidosis-gauge.js
```

---

## How Multilingual Works — Two-Layer Approach

### Layer 1 — Drupal `.po` interface translation files
Located in `translations/`, these cover:
- All PHP strings wrapped in `t()` (cow messages, risk labels, footer labels, disclaimer, JS strings)
- Not imported automatically — this module has no `.install` file. Import each `.po` file manually after enabling the module (see Installation steps below, or use the "Translate interface" UI at Admin → Configuration → Regional and language → Languages → Translate → Import)

### Layer 2 — Webform language config overrides
Located in `config/language/{langcode}/`, these override the webform's:
- Field `#title` labels
- Wizard page `#title` headings
- Select option labels (Yes/No, Short/Medium/Long, temperature options)
- Button labels (Back, Next, Calculate)

---

## Installation

```bash
# 1. Copy to Drupal
cp -r solvay_acidosis_calculator web/modules/custom/

# 2. Enable
drush en solvay_acidosis_calculator -y
drush cr

# 3. Import each language's .po file manually (no hook_install to do this automatically)
drush language:add fr
drush language:add it
drush language:add es
drush language:add nl
drush language:add de
drush locale:import fr modules/custom/solvay_acidosis_calculator/translations/solvay_acidosis_calculator.fr.po --type=customized --override=none
drush locale:import it modules/custom/solvay_acidosis_calculator/translations/solvay_acidosis_calculator.it.po --type=customized --override=none
drush locale:import es modules/custom/solvay_acidosis_calculator/translations/solvay_acidosis_calculator.es.po --type=customized --override=none
drush locale:import nl modules/custom/solvay_acidosis_calculator/translations/solvay_acidosis_calculator.nl.po --type=customized --override=none
drush locale:import de modules/custom/solvay_acidosis_calculator/translations/solvay_acidosis_calculator.de.po --type=customized --override=none

# 4. Import English base webform
drush config:import --partial \
  --source=modules/custom/solvay_acidosis_calculator/config

# 5. Import each language override
drush config:import --partial \
  --source=modules/custom/solvay_acidosis_calculator/config/language/fr
drush config:import --partial \
  --source=modules/custom/solvay_acidosis_calculator/config/language/it
drush config:import --partial \
  --source=modules/custom/solvay_acidosis_calculator/config/language/es
drush config:import --partial \
  --source=modules/custom/solvay_acidosis_calculator/config/language/nl
drush config:import --partial \
  --source=modules/custom/solvay_acidosis_calculator/config/language/de

drush cr
```

Alternatively, import translations manually via the Drupal UI:
**Configuration → Regional & Language → User interface translation → Import**

---

## Confirmation Page Architecture — read this before touching Settings → Confirmation

The rich results screen (gauge, coloured risk panel, dynamic message cards,
"Current ration values" footer) is **not** Drupal's built-in webform
confirmation message. It is a fully custom page rendered by:

```
src/Controller/AcidosisResultsController.php   (controller)
templates/ruminal-acidosis-confirmation.html.twig   (template)
solvay_acidosis_calculator.routing.yml   (route: /acidosis-calculator/results/{webform_submission})
```

The flow is:

1. User submits the form.
2. `AcidosisCalculatorHandler::postSave()` runs the calculation and stores
   the results (including the JSON-encoded dynamic message blocks) on the
   submission entity.
3. `AcidosisCalculatorHandler::confirmForm()` calls
   `$form_state->setRedirect('solvay_acidosis_calculator.results', ...)`,
   sending the browser to the custom route above.
4. `AcidosisResultsController::results()` loads the stored data, decodes the
   dynamic messages, and renders `ruminal-acidosis-confirmation.html.twig`
   via the `ruminal_acidosis_confirmation` theme hook (declared in
   `hook_theme()` in the `.module` file).

### ⚠️ Required Drupal admin setting

For step 3 to work, the webform's confirmation type **must** be:

**Structure → Webforms → Ruminal Acidosis Calculator → Settings → Confirmation**

| Setting | Required value |
|---|---|
| Confirmation type | **Page** (i.e. `confirmation_type: url` in config — NOT *Inline* or *Message*) |
| Confirmation URL | Leave blank — the handler's `setRedirect()` overrides this programmatically |
| Confirmation message / title | Leave blank — these are only used by the *Inline* type and are ignored here |

If someone changes "Confirmation type" to **Inline** in the admin UI, Drupal
will render its own `webform-confirmation.html.twig` instead of calling our
controller, and the gauge / dynamic messages / cow image will **not**
appear — only whatever plain HTML is typed into the "Confirmation message"
field. This module intentionally does not ship a `webform-confirmation.html.twig`
override, so if you ever see one in `templates/`, delete it — it is leftover
from an accidental admin misconfiguration, not part of the supported flow.

The included `config/webform.webform.solvay_acidosis_calculator.yml`
already has the correct settings (`confirmation_type: url`); re-importing it
with `drush config:import` will restore the correct behaviour if the live
site's config drifts:

```bash
drush config:import --partial \
  --source=modules/custom/solvay_acidosis_calculator/config
drush cr
```

---

## Per-Language Translation Reference

| String (EN) | FR | IT | ES | NL | DE |
|---|---|---|---|---|---|
| Low Starch Food | Aliment faible en amidon | Alimento a basso contenuto di amido | Alimento bajo en almidón | Laag zetmeelvoer | Stärkearmes Futter |
| Corn | Maïs | Mais | Maíz | Maïs | Mais |
| Silomais | Ensilage de maïs | Insilato di mais | Ensilaje de maíz | Maïskuil | Maissilage |
| Alfalfa | Luzerne | Erba medica | Alfalfa | Luzerne | Luzerne |
| Straw | Paille | Paglia | Paja | Stro | Stroh |
| Short (<3cm) | Court (<3 cm) | Corto (<3 cm) | Corto (<3 cm) | Kort (<3 cm) | Kurz (<3 cm) |
| Hot (>28°C) | Très chaude | Molto calda | Calurosa | Heet | Heiß |
| Calculate | Calculer | Calcola | Calcular | Berekenen | Berechnen |
| Dry Substance | Matière sèche | Sostanza secca | Materia seca | Droge stof | Trockensubstanz |
| Starch (%) | Amidon (%) | Amido (%) | Almidón (%) | Zetmeel (%) | Stärke (%) |

---

## Adding More Languages

1. Copy any existing `.po` file, rename it `solvay_acidosis_calculator.{langcode}.po`, translate all `msgstr` lines.
2. Copy any language config override folder, rename it to the new `{langcode}`, update all labels.
3. Run `drush locale:import {langcode} path/to/file.po` and `drush config:import --partial --source=.../config/language/{langcode}`.
