/**
 * @file
 * Fetches the AI-personalized dosage/ration recommendation after the
 * results page has rendered, and populates the AI panel. Fails silently
 * (panel stays hidden) if the request fails, times out, or the feature
 * is disabled server-side — the rule-based results above are always
 * fully usable on their own regardless of this script's outcome.
 */

(function (Drupal, once) {
  'use strict';

  Drupal.behaviors.solvayAcidosisAiRecommendation = {
    attach: function (context) {
      once('acidosis-ai-panel', '#acidosis-ai-panel', context).forEach(function (panel) {
        var submissionId = panel.getAttribute('data-submission-id');
        if (!submissionId) {
          return;
        }

        var loadingEl = panel.querySelector('.ai-loading');
        var explanationEl = panel.querySelector('.ai-explanation');
        var adjustmentsEl = panel.querySelector('.ai-adjustments');
        var dosageEl = panel.querySelector('.ai-refined-dosage');

        var url = '/acidosis-calculator/results/' + encodeURIComponent(submissionId) + '/ai-recommendation';

        // Show a loading skeleton while we wait, since the LLM call can
        // take a few seconds and the panel starts hidden.
        panel.style.display = 'block';
        if (loadingEl) {
          loadingEl.style.display = 'block';
        }

        var controller = new AbortController();
        var timeoutId = setTimeout(function () {
          controller.abort();
        }, 10000);

        fetch(url, {
          method: 'GET',
          headers: { 'Accept': 'application/json' },
          signal: controller.signal,
        })
          .then(function (response) {
            clearTimeout(timeoutId);
            if (!response.ok) {
              throw new Error('Request failed with status ' + response.status);
            }
            return response.json();
          })
          .then(function (data) {
            if (!data || data.available === false) {
              // Feature disabled, budget exhausted, or no recommendation
              // could be generated — hide the panel entirely rather than
              // show an empty/broken section.
              panel.style.display = 'none';
              return;
            }
            renderRecommendation(data);
          })
          .catch(function (error) {
            // Network error, timeout, malformed response, etc. Hide the
            // panel — the farmer already has the full rule-based result
            // above and should never see a broken AI section.
            clearTimeout(timeoutId);
            panel.style.display = 'none';
            if (window.console && window.console.warn) {
              window.console.warn('Acidosis AI recommendation unavailable:', error);
            }
          });

        function renderRecommendation(data) {
          if (loadingEl) {
            loadingEl.style.display = 'none';
          }

          if (explanationEl && data.explanation) {
            explanationEl.textContent = data.explanation;
          }

          if (adjustmentsEl && Array.isArray(data.adjustments)) {
            adjustmentsEl.innerHTML = '';
            data.adjustments.forEach(function (adjustment) {
              var li = document.createElement('li');
              li.textContent = adjustment;
              adjustmentsEl.appendChild(li);
            });
          }

          if (dosageEl && data.refined_dosage_g) {
            dosageEl.textContent = Drupal.t(
              'Personalized recommended dosage: @dosage g/day',
              { '@dosage': data.refined_dosage_g }
            );
          }
        }
      });
    }
  };

})(Drupal, once);
