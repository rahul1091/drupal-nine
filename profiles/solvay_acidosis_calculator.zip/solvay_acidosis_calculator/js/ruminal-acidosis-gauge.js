/**
 * @file
 * ruminal-acidosis-gauge.js  (v3)
 *
 * Animates the SVG gauge needle on the results page. The colored arc itself
 * is now the static images/bg_indicator.png (see the Twig template) — this
 * SVG only draws the needle on top of it, as a transparent overlay.
 * SVG viewBox is "0 0 269 140" (matches bg_indicator.png's own pixel size
 * so the needle's pivot lines up with the image's arc), pivot centre is
 * (134.5, 132). Needle starts at -90° (full LEFT = LOW) and sweeps to the
 * target angle.
 * Target angle maps: risk_score 0–5 (sub-acidosis risk index)  →  -90° to +90°
 */
(function (Drupal, drupalSettings) {
  'use strict';

  var PIVOT_X = 134.5;
  var PIVOT_Y = 132;

  Drupal.behaviors.ruminalAcidosisGauge = {
    attach: function (context, settings) {

      // Support both document context and Ajax fragment context.
      var gaugeEl = context.querySelector
        ? context.querySelector('#gauge-needle')
        : null;

      if (!gaugeEl && context.id === 'gauge-needle') {
        gaugeEl = context;
      }

      if (!gaugeEl) return;
      if (gaugeEl.dataset.animated) return;   // idempotent on re-attach
      gaugeEl.dataset.animated = 'true';

      var config      = (settings && settings.ruminalAcidosisResults) || {};
      var targetAngle = parseFloat(config.needleAngle) || -90;   // -90 to +90

      // Clamp to valid arc range.
      targetAngle = Math.max(-90, Math.min(90, targetAngle));

      var startAngle = -90;
      var duration   = 1400;   // ms
      var startTime  = null;

      function easeOutCubic(t) {
        return 1 - Math.pow(1 - t, 3);
      }

      function frame(timestamp) {
        if (!startTime) startTime = timestamp;
        var elapsed  = timestamp - startTime;
        var progress = Math.min(elapsed / duration, 1);
        var angle    = startAngle + (targetAngle - startAngle) * easeOutCubic(progress);

        // Pivot point is (134.5, 132) — matches the SVG viewBox / bg image.
        gaugeEl.setAttribute('transform', 'rotate(' + angle.toFixed(2) + ', ' + PIVOT_X + ', ' + PIVOT_Y + ')');

        if (progress < 1) {
          requestAnimationFrame(frame);
        }
      }

      requestAnimationFrame(frame);
    },
  };

}(Drupal, drupalSettings));
