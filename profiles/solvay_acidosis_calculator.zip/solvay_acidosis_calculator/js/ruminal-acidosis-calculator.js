/**
 * @file
 * ruminal-acidosis-calculator.js  (v3)
 *
 * Root causes of the triple-footer:
 *  1. Drupal renders a pre-existing "Current ration values" webform_markup
 *     element inside the form (if one was accidentally left in the YAML).
 *  2. The JS injected its own footer on every attach() call because the
 *     document-level ID guard still failed when Drupal's Ajax swapped the
 *     entire #drupal-ajax-wrapper (which removed the previously inserted
 *     sibling element from the DOM).
 *  3. A theme block region independently renders the footer above the form.
 *
 * Fix strategy:
 *  - Use a flag on window (not DOM) to know if we've already wired the footer.
 *  - On every attach(), remove ALL .acidosis-ration-footer elements that are
 *    INSIDE the form or its Ajax wrapper, then ensure exactly ONE lives
 *    immediately after the outermost stable wrapper.
 *  - CSS hides the progress bar and "N of 5" counter unconditionally.
 */
(function ($, Drupal, drupalSettings) {
  'use strict';

  var NUTRITION   = (drupalSettings.ruminalAcidosis && drupalSettings.ruminalAcidosis.nutritionData) || {};
  var GRAM_FIELDS = ['sodium_bicarbonate', 'magnesium_oxide'];
  var FOOTER_ID   = 'acidosis-ration-footer-singleton';
  var MODAL_ID    = 'acidosis-nutrition-modal';

  // Ingredient labels shown as the modal header (mirrors the field '#title'
  // in the webform YAML / the Angular app's FORM labels).
  var FIELD_LABELS = {
    low_starch_food:    'Low Starch Food (20-25% Starch)',
    nucleus_soya:       'Nucleus, Soya or other proteins',
    corn:               'Corn',
    high_starch_diet:   'High starch diet, barley or other grains',
    corn_barley_flakes: 'Corn or Barley Flakes',
    silomais:           'Silomais',
    mash:               'Mash',
    sorgum_silage:      'Sorgum silage',
    other_baleage:      'Other baleage',
    alfalfa:            'Alfalfa',
    other_hay:          'Other types of hay',
    straw:              'Straw'
  };

  // Which hidden field carries the JSON override blob. Both page_1 and
  // page_2 have their own hidden field (Drupal webform elements must live
  // on a specific wizard page); we simply keep both in sync with the full
  // overrides object so no data is lost regardless of which page the user
  // is on when the final "Calculate" submission happens.
  var OVERRIDE_HIDDEN_FIELD = {
    page1: 'page_1_nutrition_overrides',
    page2: 'page_2_nutrition_overrides'
  };

  // ── Cross-page persistence ────────────────────────────────────────────────
  //
  // This is a multi-page (wizard) webform with Ajax enabled. Each Ajax page
  // transition swaps the ENTIRE form fragment in the DOM, so fields entered
  // on earlier pages (e.g. Concentrates) are no longer present once the user
  // moves to a later page (e.g. Silage & Hay, or Symptoms). Without this
  // store, readFieldValues() would silently treat "field not in the current
  // DOM" the same as "field is 0", causing the running "Current ration
  // values" footer to reset on every page instead of accumulating like the
  // Angular calculator does. This object lives in the closure (not the DOM),
  // so it survives every Ajax attach() for as long as the browser tab is open,
  // and is the single source of truth for "last known value" of every field.
  var persistedValues = {};
  Object.keys(NUTRITION).forEach(function (field) {
    persistedValues[field] = 0;
  });

  // ── Nutrient overrides (the "+" popup) ───────────────────────────────────
  //
  // Clicking "+" next to an ingredient opens a popup (matching the Angular
  // app's calculator-popup) where the user can override that ingredient's
  // Dry Substance / Starch / NDF values (e.g. for a specific batch of feed
  // that doesn't match the built-in default). Like persistedValues above,
  // this lives in the closure so it survives Ajax page transitions. Only
  // 'dm' (fraction), 'starch' and 'ndf' can be overridden — all other
  // nutrient fields (adf, pendf, issd, kd, kp, pt) always come from the
  // built-in NUTRITION defaults, exactly like the Angular popup only
  // exposes Dry Substance / Starch / NDF.
  var overrides = {};

  function getEffectiveNutrition(field) {
    var base = NUTRITION[field] || {};
    var ov   = overrides[field];
    if (!ov) return base;
    return $.extend({}, base, {
      dm:     (typeof ov.dm === 'number')     ? ov.dm     : base.dm,
      starch: (typeof ov.starch === 'number') ? ov.starch : base.starch,
      ndf:    (typeof ov.ndf === 'number')    ? ov.ndf    : base.ndf
    });
  }

  function writeOverridesToHiddenField($form) {
    Object.keys(OVERRIDE_HIDDEN_FIELD).forEach(function (pageKey) {
      var hiddenName = OVERRIDE_HIDDEN_FIELD[pageKey];
      var $hidden = $form.find('[name*="' + hiddenName + '"]').first();
      if ($hidden.length) {
        $hidden.val(JSON.stringify(overrides));
      }
    });
  }

  // ── Calculation helpers ───────────────────────────────────────────────────

  function readFieldValues() {
    Object.keys(NUTRITION).forEach(function (field) {
      var $input = $('[name*="' + field + '"]').first();
      // Only fields that are actually rendered on the CURRENT wizard page
      // update the persisted store. Fields belonging to other pages are left
      // untouched so their last entered value keeps counting toward the
      // running ration total.
      if ($input.length) {
        persistedValues[field] = parseFloat($input.val()) || 0;
      }
    });
    // Return a shallow copy so callers can't mutate the persisted store.
    return $.extend({}, persistedValues);
  }

  function computeRationTotals(values) {
    var totalDm = 0, totalStarchDm = 0, totalNdfDm = 0;
    Object.keys(NUTRITION).forEach(function (field) {
      if (GRAM_FIELDS.indexOf(field) !== -1) return;
      var kgAsFed = values[field] || 0;
      if (kgAsFed <= 0) return;
      var data = getEffectiveNutrition(field);
      var kgDm = kgAsFed * data.dm;
      totalDm       += kgDm;
      totalStarchDm += kgDm * (data.starch / 100);
      totalNdfDm    += kgDm * (data.ndf    / 100);
    });
    return {
      drySubstance : totalDm,
      starchPercent: totalDm > 0 ? (totalStarchDm / totalDm) * 100 : 0,
      ndfPercent   : totalDm > 0 ? (totalNdfDm    / totalDm) * 100 : 0,
    };
  }

  function updateFooter() {
    var t = computeRationTotals(readFieldValues());
    $('#' + FOOTER_ID + ' .acidosis-footer-ds').text(t.drySubstance.toFixed(2));
    $('#' + FOOTER_ID + ' .acidosis-footer-starch').text(t.starchPercent.toFixed(2));
    $('#' + FOOTER_ID + ' .acidosis-footer-ndf').text(t.ndfPercent.toFixed(2));
  }

  function buildFooterHtml() {
    return '<div id="' + FOOTER_ID + '" class="acidosis-ration-footer">' +
      '<hr class="acidosis-ration-footer__divider">' +
      '<div class="acidosis-ration-footer__inner">' +
        '<strong>' + Drupal.t('Current ration values') + '</strong>' +
        '<div class="acidosis-ration-footer__values">' +
          '<div class="acidosis-ration-footer__value-box">' +
            '<span class="acidosis-ration-footer__number acidosis-footer-ds">0.00</span>' +
            '<span class="acidosis-ration-footer__label">' + Drupal.t('Dry Substance (Kg/cow/day)') + '</span>' +
          '</div>' +
          '<div class="acidosis-ration-footer__value-box">' +
            '<span class="acidosis-ration-footer__number acidosis-footer-starch">0.00</span>' +
            '<span class="acidosis-ration-footer__label">' + Drupal.t('Starch (%)') + '</span>' +
          '</div>' +
          '<div class="acidosis-ration-footer__value-box">' +
            '<span class="acidosis-ration-footer__number acidosis-footer-ndf">0.00</span>' +
            '<span class="acidosis-ration-footer__label">' + Drupal.t('NDF (%)') + '</span>' +
          '</div>' +
        '</div>' +
      '</div>' +
    '</div>';
  }

  // ── Footer management ─────────────────────────────────────────────────────

  function ensureFooter($form) {
    // Step 1: remove every copy of the footer that sits INSIDE the form or its
    // Ajax wrapper — these are stale injections or theme-rendered markup blocks.
    $form.find('.acidosis-ration-footer').remove();

    // Also remove any duplicate that ended up outside the form (prior runs).
    // Keep only the one we're about to place.
    $('#' + FOOTER_ID).remove();

    // Step 2: find the best anchor — the outermost stable container around $form.
    // Drupal wraps Ajax forms in a div[data-drupal-selector] or .webform-submission-form.
    var $anchor = $form.closest('[data-drupal-selector]');
    if (!$anchor.length) $anchor = $form;

    // Step 3: insert exactly one footer immediately after the anchor.
    $anchor.after(buildFooterHtml());
  }

  // ── Nutrient override modal ───────────────────────────────────────────────
  //
  // Mirrors the Angular app's calculator-popup: lets the user override a
  // single ingredient's Dry Substance / Starch / NDF values. "Update" saves
  // the override (used for both the live footer preview AND the final
  // server-side calculation, via the hidden JSON fields). "Reset" restores
  // that ingredient's built-in defaults. Closing the popup (X) without
  // clicking either button discards unsaved edits.

  function closeModal() {
    $('#' + MODAL_ID).remove();
  }

  function openNutritionModal(field, $form) {
    closeModal();

    var label     = Drupal.t(FIELD_LABELS[field] || field);
    var effective = getEffectiveNutrition(field);
    // Dry Substance is displayed/edited as a whole percentage (e.g. "87"),
    // matching the Angular popup — internally we store it as a 0–1 fraction.
    var dsPercent = Math.round((effective.dm || 0) * 100 * 100) / 100;

    var $overlay = $(
      '<div id="' + MODAL_ID + '" class="acidosis-modal-overlay">' +
        '<div class="acidosis-modal" role="dialog" aria-modal="true">' +
          '<button type="button" class="acidosis-modal__close" aria-label="' + Drupal.t('Close') + '">&times;</button>' +
          '<div class="acidosis-modal__header">' + label + '</div>' +
          '<div class="acidosis-modal__body">' +
            '<div class="acidosis-modal__field">' +
              '<label>' + Drupal.t('Dry Substance') + '</label>' +
              '<input type="number" step="0.01" class="acidosis-modal__input" data-key="dm" value="' + dsPercent + '">' +
            '</div>' +
            '<div class="acidosis-modal__field">' +
              '<label>' + Drupal.t('Starch') + '</label>' +
              '<input type="number" step="0.01" class="acidosis-modal__input" data-key="starch" value="' + effective.starch + '">' +
            '</div>' +
            '<div class="acidosis-modal__field">' +
              '<label>' + Drupal.t('NDF') + '</label>' +
              '<input type="number" step="0.01" class="acidosis-modal__input" data-key="ndf" value="' + effective.ndf + '">' +
            '</div>' +
          '</div>' +
          '<div class="acidosis-modal__notice"></div>' +
          '<div class="acidosis-modal__actions">' +
            '<button type="button" class="acidosis-modal__btn acidosis-modal__btn--update">' + Drupal.t('Update') + '</button>' +
            '<button type="button" class="acidosis-modal__btn acidosis-modal__btn--reset">' + Drupal.t('Reset') + '</button>' +
          '</div>' +
          '<div class="acidosis-modal__footnote">' + Drupal.t('The values entered are standard for Italian food') + '</div>' +
        '</div>' +
      '</div>'
    );

    function showNotice(text) {
      var $notice = $overlay.find('.acidosis-modal__notice');
      $notice.text(text).addClass('is-visible');
      setTimeout(function () { $notice.removeClass('is-visible').text(''); }, 2000);
    }

    $overlay.on('click', function (e) {
      if (e.target === this) closeModal();
    });
    $overlay.find('.acidosis-modal__close').on('click', closeModal);

    $overlay.find('.acidosis-modal__btn--update').on('click', function () {
      var dm     = parseFloat($overlay.find('[data-key="dm"]').val());
      var starch = parseFloat($overlay.find('[data-key="starch"]').val());
      var ndf    = parseFloat($overlay.find('[data-key="ndf"]').val());

      overrides[field] = {
        dm:     isNaN(dm)     ? (NUTRITION[field] || {}).dm     : dm / 100,
        starch: isNaN(starch) ? (NUTRITION[field] || {}).starch : starch,
        ndf:    isNaN(ndf)    ? (NUTRITION[field] || {}).ndf    : ndf
      };

      writeOverridesToHiddenField($form);
      updateFooter();
      showNotice(Drupal.t('Values updated'));
    });

    $overlay.find('.acidosis-modal__btn--reset').on('click', function () {
      delete overrides[field];
      writeOverridesToHiddenField($form);

      var defaults = NUTRITION[field] || {};
      $overlay.find('[data-key="dm"]').val(Math.round((defaults.dm || 0) * 100 * 100) / 100);
      $overlay.find('[data-key="starch"]').val(defaults.starch);
      $overlay.find('[data-key="ndf"]').val(defaults.ndf);

      updateFooter();
      showNotice(Drupal.t('Values reset to default'));
    });

    $('body').append($overlay);
  }

  // ── "+" buttons (open the nutrient override modal) ───────────────────────

  function addOverrideButtons($form) {
    Object.keys(NUTRITION).forEach(function (field) {
      if (GRAM_FIELDS.indexOf(field) !== -1) return;

      var $input = $form.find('[name*="' + field + '"]').first();
      if (!$input.length) return;

      var $formItem = $input.closest('.js-form-item, .form-item');
      if (!$formItem.length || $formItem.hasClass('acidosis-field-row')) return;

      $formItem.addClass('acidosis-field-row');

      // Wrap input in a flex shell.
      $input.wrap('<span class="acidosis-input-shell"></span>');

      var $btn = $('<button type="button" class="acidosis-increment-btn" aria-label="' +
        Drupal.t('Edit nutrient values') + '">+</button>');

      $btn.on('click', function () {
        openNutritionModal(field, $form);
      });

      $input.parent('.acidosis-input-shell').append($btn);
    });
  }

  // ── Main Drupal behaviour ─────────────────────────────────────────────────

  Drupal.behaviors.ruminalAcidosisCalculator = {
    attach: function (context, settings) {
      // Resolve $form — works whether context is document or an Ajax fragment.
      var $form = $(context).find('[id^="webform-submission-ruminal-acidosis"]');
      if (!$form.length && $(context).is('[id^="webform-submission-ruminal-acidosis"]')) {
        $form = $(context);
      }
      if (!$form.length) return;

      // Always re-run ensureFooter on every attach() so Ajax page transitions
      // clean up any duplicates that crept back in.
      ensureFooter($form);
      addOverrideButtons($form);
      // Re-apply the in-memory overrides to whichever hidden field is
      // present on this page, so they always travel with the submission.
      writeOverridesToHiddenField($form);
      updateFooter();

      // Re-bind input listener (namespaced so it's safe to call repeatedly).
      $form.off('input.acidosis change.acidosis')
           .on('input.acidosis change.acidosis', 'input[type="number"], input[type="text"]', updateFooter);
    },
  };

}(jQuery, Drupal, drupalSettings));
