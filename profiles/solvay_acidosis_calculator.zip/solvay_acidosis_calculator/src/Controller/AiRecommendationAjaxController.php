<?php

namespace Drupal\solvay_acidosis_calculator\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\webform\WebformSubmissionInterface;
use Drupal\solvay_acidosis_calculator\Service\AiRecommendationService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Serves the AI-personalized dosage/ration recommendation as JSON, fetched
 * asynchronously by js/ai-recommendation.js after the results page (built
 * by AcidosisResultsController) has already rendered the rule-based score.
 *
 * Route: /acidosis-calculator/results/{webform_submission}/ai-recommendation
 * Reuses AcidosisResultsController::access() for identical access rules
 * (submission owner, anonymous, or "administer webform submission").
 *
 * This endpoint NEVER throws a hard error back to the browser for
 * feature-disabled / budget-exhausted / AI-call-failed cases — it always
 * returns 200 with an "available" flag, so the front end can distinguish
 * "cleanly not available" from an actual HTTP failure (network error,
 * access denied, etc.), per the graceful-degradation design.
 */
class AiRecommendationAjaxController extends ControllerBase {

  public function __construct(
    protected AiRecommendationService $aiRecommendationService,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('solvay_acidosis_calculator.ai_recommendation'),
    );
  }

  /**
   * Returns the AI recommendation for a given submission, or
   * {"available": false} if the feature is off, budget-exhausted, or the
   * AI call itself failed.
   */
  public function get(WebformSubmissionInterface $webform_submission): JsonResponse {
    $data = $webform_submission->getData();

    // Same guard as AcidosisResultsController::results(): if the rule-based
    // calculation hasn't actually run for this submission, there's nothing
    // to build a recommendation from.
    if (empty($data['result_risk_level'])) {
      return new JsonResponse(['available' => FALSE]);
    }

    $config = $this->config('solvay_acidosis_calculator.settings');
    if (!$config->get('ai_enabled')) {
      return new JsonResponse(['available' => FALSE]);
    }

    // Site-wide daily call budget check (see AiSettingsForm's
    // daily_call_budget setting). 0 = unlimited.
    $budget = (int) ($config->get('daily_call_budget') ?? 0);
    if ($budget > 0 && !$this->withinDailyBudget($budget)) {
      return new JsonResponse(['available' => FALSE]);
    }

    // Build the rule-based result summary the AI service needs, straight
    // from the already-computed/stored submission data — no need to
    // re-run AcidosisCalculatorService here.
    $rule_based_result = $this->buildRuleBasedSummary($data);

    // The ration inputs the farmer originally entered on the webform (not
    // the computed result_* fields), so the AI has the actual context to
    // reason about — e.g. concentrate/forage percentages, buffer already
    // fed, symptoms observed, etc. Adjust this key list to match your
    // webform's actual element machine names.
    $inputs = $this->extractRationInputs($data);

    $recommendation = $this->aiRecommendationService->getRecommendation(
      (int) $webform_submission->id(),
      $inputs,
      $rule_based_result,
    );

    if ($recommendation === NULL) {
      // AiRecommendationService already logged the specific failure reason
      // (timeout, malformed response, API error, etc.) — nothing further
      // to do here except degrade gracefully.
      return new JsonResponse(['available' => FALSE]);
    }

    return new JsonResponse([
      'available'          => TRUE,
      'explanation'        => $recommendation['explanation'] ?? '',
      'adjustments'        => $recommendation['adjustments'] ?? [],
      'refined_dosage_g'   => $recommendation['refined_dosage_g'] ?? NULL,
    ]);
  }

  /**
   * NOTE: this route uses requirements._permission: 'access content' in
   * routing.yml (matching the existing solvay_acidosis_calculator.results
   * route's pattern), rather than a custom access callback. If you want
   * this endpoint to enforce the same owner/anonymous/admin rules as
   * AcidosisResultsController::access(), switch routing.yml's requirement
   * to _custom_access and re-add a matching access() method here.
   */

  /**
   * Builds the minimal rule-based summary AiRecommendationService's prompt
   * needs: the computed score/risk level, plus a dosage band used as a
   * hard guardrail so the AI can never suggest a dosage outside it.
   *
   * NOTE: the stored submission only has a single recommended dosage
   * value (result_recommended_dosage), not an explicit min/max band. This
   * derives a ±15% band around it as a placeholder guardrail — replace
   * with real veterinary-approved bounds before going to production.
   */
  protected function buildRuleBasedSummary(array $data): array {
    $dosage = (float) ($data['result_recommended_dosage'] ?? 0);

    return [
      'score'       => (float) ($data['result_risk_score'] ?? 0),
      'risk_level'  => $data['result_risk_level'] ?? '',
      'dosage_min'  => (int) round($dosage * 0.85),
      'dosage_max'  => (int) round($dosage * 1.15),
    ];
  }

  /**
   * Extracts the original ration/form inputs relevant to the AI prompt
   * from the submission data. Update the key list below to match your
   * webform's actual element machine names — these are placeholders
   * based on the fields referenced elsewhere in this module (dry
   * substance, starch %, NDF %, buffer, symptoms, heat stress).
   */
  protected function extractRationInputs(array $data): array {
    $keys = [
      'concentrates',
      'forages',
      'dry_substance',
      'starch_percent',
      'ndf_percent',
      'buffer_fed',
      'symptoms_observed',
      'heat_stress',
      'breed',
      'lactation_stage',
      'region',
    ];

    $inputs = [];
    foreach ($keys as $key) {
      if (isset($data[$key])) {
        $inputs[$key] = $data[$key];
      }
    }

    return $inputs;
  }

  /**
   * Simple site-wide daily call counter using the State API. Not
   * perfectly atomic under very high concurrency (a lock could be added
   * via \Drupal::lock() if needed), but adequate as a soft safety cap
   * rather than a hard billing-critical limit.
   */
  protected function withinDailyBudget(int $budget): bool {
    $state = \Drupal::state();
    $today = date('Y-m-d');
    $key   = 'solvay_acidosis_calculator.ai_calls.' . $today;

    $count = (int) $state->get($key, 0);
    if ($count >= $budget) {
      return FALSE;
    }

    $state->set($key, $count + 1);
    return TRUE;
  }

}
