<?php

namespace Drupal\solvay_acidosis_calculator\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Url;
use Drupal\webform\WebformSubmissionInterface;

/**
 * Renders the acidosis risk results page for a given webform submission.
 *
 * Reached via the webform's "URL redirect" confirmation setting, which the
 * AcidosisCalculatorHandler::confirmForm() sets programmatically. The route
 * is /acidosis-calculator/results/{webform_submission} (see routing.yml).
 *
 * IMPORTANT — Drupal admin requirement:
 *   The webform's Settings → Confirmation → "Confirmation type" MUST be set
 *   to "Page" / "URL redirect" (confirmation_type: url in config), NOT
 *   "Inline" or "Message". If set to Inline, Drupal renders its own
 *   webform-confirmation.html.twig instead of calling this controller, and
 *   none of the gauge/dynamic-message markup below will ever appear.
 */
class AcidosisResultsController extends ControllerBase {

  /**
   * Default-language (English) path alias for the page where the
   * calculator form itself is placed (a node using this alias). Used as
   * the lookup key to resolve the "Back" / "Recalculate" link — see
   * buildFormUrl() below, since other languages use entirely different,
   * independently-translated aliases (not this string with a langcode
   * prefix) — e.g. French is '/brands/bicarz/lacidose-du-remen', Italian
   * is '/brands/bicarz/capire-lacidosi-ruminale'.
   */
  protected const FORM_PATH = '/en/rumen-acidosis';

  /**
   * Builds the confirmation/results page render array.
   */
  public function results(WebformSubmissionInterface $webform_submission): array {
    $data = $webform_submission->getData();

    if (empty($data['result_risk_level'])) {
      // Calculation hasn't run yet (e.g. direct URL visit before submitting).
      return [
        '#markup' => '<p>' . $this->t('No results are available for this submission yet. Please complete the calculator form first.') . '</p>',
      ];
    }

    // The risk score is the "sub-acidosis risk index", a 0–5 scale (matching
    // the Bicar®Z Angular app's subAcidosisRisk value), not 0–10.
    $raw_score    = (float) ($data['result_risk_score'] ?? 0);
    $clamped      = min(max($raw_score, 0), 5);
    $needle_angle = ($clamped / 5) * 180 - 90;   // -90° = LOW, +90° = HIGH

    // URL back to the calculator form page, for the Back / Recalculate
    // buttons. See buildFormUrl() for why this can't just be a langcode
    // prefix on self::FORM_PATH — each language has its own, independently
    // translated alias (e.g. '/de/risikorechner-fuer-pansenazidose').
    $form_url = $this->buildFormUrl();

    // Absolute URL to the gauge's background arc image (images/bg_indicator.png),
    // resolved via the module's own extension path so it works regardless of
    // where the module is installed (contrib vs custom, multisite, etc.).
    $module_path     = \Drupal::service('extension.list.module')->getPath('solvay_acidosis_calculator');
    $gauge_image_url = base_path() . $module_path . '/images/bg_indicator.png';

    // Decode the JSON-encoded dynamic messages stored by the handler.
    $dynamic_messages = [];
    if (!empty($data['result_dynamic_messages'])) {
      $decoded = json_decode($data['result_dynamic_messages'], TRUE);
      if (is_array($decoded)) {
        $dynamic_messages = $decoded;
      }
    }

    return [
      '#theme'              => 'ruminal_acidosis_confirmation',
      // Core results
      '#risk_level'         => $data['result_risk_level'],
      '#risk_score'         => $raw_score,
      '#risk_label'         => $data['result_risk_label'],
      '#recommended_dosage' => $data['result_recommended_dosage'],
      '#estimated_fat'      => $data['result_estimated_fat'],
      '#cow_message'        => $data['result_cow_message'],
      '#panel_color'        => $data['result_panel_color'],
      '#dry_substance'      => $data['result_dry_substance'],
      '#starch_percent'     => $data['result_starch_percent'],
      '#ndf_percent'        => $data['result_ndf_percent'],
      '#submission_id'      => $webform_submission->id(),
      '#gauge_image_url'    => $gauge_image_url,
      // Signal statuses
      '#starch_status'      => $data['result_starch_status']     ?? 'optimal',
      '#ndf_status'         => $data['result_ndf_status']        ?? 'optimal',
      '#heat_stress'        => $data['result_heat_stress']       ?? 'none',
      '#symptoms_observed'  => ($data['result_symptoms_observed'] ?? '0') === '1',
      '#buffer_status'      => $data['result_buffer_status']     ?? 'none',
      // Dynamic messages array
      '#dynamic_messages'   => $dynamic_messages,
      '#attached'           => [
        'library'        => [
          'solvay_acidosis_calculator/results',
          'solvay_acidosis_calculator/ai_recommendation',
        ],
        'drupalSettings' => [
          'ruminalAcidosisResults' => [
            'needleAngle' => $needle_angle,
            'riskLevel'   => $data['result_risk_level'],
            'riskScore'   => $raw_score,
            'formUrl'     => $form_url,
          ],
        ],
      ],
    ];
  }

  /**
   * Access callback: allow submission owner or admin.
   */
  public function access(
    WebformSubmissionInterface $webform_submission,
    AccountInterface $account
  ): AccessResult {
    if ($account->hasPermission('administer webform submission')) {
      return AccessResult::allowed();
    }
    $owner_uid = $webform_submission->getOwnerId();
    if ($owner_uid && $account->id() === $owner_uid) {
      return AccessResult::allowed();
    }
    return $account->isAnonymous() ? AccessResult::allowed() : AccessResult::forbidden();
  }

  /**
   * Resolves the calculator form page's URL in the CURRENT interface
   * language.
   *
   * self::FORM_PATH ('/brands/bicarz/rumen-acidosis') is only the
   * DEFAULT-language alias. Other languages use their own, independently
   * translated aliases that bear no resemblance to it — e.g. French is
   * '/brands/bicarz/lacidose-du-remen', Italian is
   * '/brands/bicarz/capire-lacidosi-ruminale'. So we can't just prepend a
   * langcode to self::FORM_PATH.
   *
   * Instead:
   *  1. Resolve self::FORM_PATH to its internal system path (e.g.
   *     '/node/123') using the DEFAULT language explicitly, since that's
   *     the language the alias string itself is written in.
   *  2. Re-generate a URL for that internal path in the CURRENT language.
   *     Drupal's outbound alias lookup then substitutes THAT language's
   *     own translated alias automatically.
   *
   * NOTE — this is independent of whether the language shows up in the
   * URL at all (path prefix like '/de/...', a separate domain, or no
   * visible marker at all/session-based negotiation). Aliases are looked
   * up and generated by LANGCODE, not by parsing/guessing URL structure,
   * so no changes are needed for sites that don't use path-prefix
   * negotiation — getCurrentLanguage() already reflects however the site
   * negotiates language (domain, session, path, etc.), and
   * getPathByAlias()/Url::fromUserInput() key off that langcode alone.
   *
   * This relies on the calculator page's node having a translated path
   * alias configured for each language (Content Translation / URL alias
   * translation). If a translated alias is genuinely missing for the
   * current language, Drupal falls back to the internal system path
   * (e.g. '/node/123') for that language — the link still works, it's
   * just not a "pretty" URL. If self::FORM_PATH itself can't be resolved
   * at all (e.g. the default-language alias was changed/removed), fall
   * back to self::FORM_PATH so the button never ends up with an empty
   * or broken href.
   */
  protected function buildFormUrl(): string {
    $language_manager = \Drupal::languageManager();
    $default_langcode = $language_manager->getDefaultLanguage()->getId();
    $current_language = $language_manager->getCurrentLanguage();

    /** @var \Drupal\path_alias\AliasManagerInterface $alias_manager */
    $alias_manager = \Drupal::service('path_alias.manager');
    $internal_path = $alias_manager->getPathByAlias(self::FORM_PATH, $default_langcode);

    // getPathByAlias() returns the input unchanged if no matching alias is
    // found at all — meaning self::FORM_PATH itself is stale/wrong. In
    // that case there's no internal path to re-resolve, so just use the
    // configured alias as-is rather than risk generating a broken link.
    if ($internal_path === self::FORM_PATH) {
      return self::FORM_PATH;
    }

    return Url::fromUserInput($internal_path, [
      'language' => $current_language,
    ])->toString();
  }

}
