<?php

namespace Drupal\solvay_acidosis_calculator\Plugin\WebformHandler;

use Drupal\Core\Form\FormStateInterface;
use Drupal\webform\Plugin\WebformHandlerBase;
use Drupal\webform\WebformSubmissionInterface;
use Drupal\solvay_acidosis_calculator\Service\AcidosisCalculatorService;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Acidosis Calculator Webform Handler.
 *
 * Runs after a submission is saved:
 *  1. Reads all field values from the submission.
 *  2. Passes them to AcidosisCalculatorService::calculate().
 *  3. Stores ALL result fields (including dynamic_messages) back on submission.
 *  4. Redirects to the custom results page.
 *
 * @WebformHandler(
 *   id = "acidosis_calculator",
 *   label = @Translation("Acidosis Risk Calculator"),
 *   category = @Translation("Custom"),
 *   description = @Translation("Calculates ruminal acidosis risk, dynamic messages, and BicarZ dosage."),
 *   cardinality = \Drupal\webform\Plugin\WebformHandlerInterface::CARDINALITY_SINGLE,
 *   results = \Drupal\webform\Plugin\WebformHandlerInterface::RESULTS_PROCESSED,
 *   submission = \Drupal\webform\Plugin\WebformHandlerInterface::SUBMISSION_REQUIRED,
 * )
 */
class AcidosisCalculatorHandler extends WebformHandlerBase {

  protected AcidosisCalculatorService $calculatorService;

  public static function create(
    ContainerInterface $container,
    array $configuration,
    $plugin_id,
    $plugin_definition
  ) {
    $instance = parent::create($container, $configuration, $plugin_id, $plugin_definition);
    $instance->calculatorService = $container->get('solvay_acidosis_calculator.calculator');
    return $instance;
  }

  /**
   * {@inheritdoc}
   * Called after the submission is saved. Runs calculation and stores results.
   */
  public function postSave(WebformSubmissionInterface $webform_submission, $update = TRUE): void {
    $values = $webform_submission->getData();
    $result = $this->calculatorService->calculate($values);

    $stored_data = array_merge($values, [
      // ── Core calculation results ──────────────────────────────────────
      'result_risk_level'         => $result['risk_level'],
      'result_risk_label'         => $result['risk_label'],
      'result_risk_score'         => $result['risk_score'],
      'result_recommended_dosage' => $result['recommended_dosage'],
      'result_estimated_fat'      => $result['estimated_fat'],
      'result_dry_substance'      => $result['dry_substance'],
      'result_starch_percent'     => $result['starch_percent'],
      'result_ndf_percent'        => $result['ndf_percent'],
      'result_cow_message'        => $result['cow_message'],
      'result_panel_color'        => $result['panel_color'],
      // ── Signal statuses ───────────────────────────────────────────────
      'result_starch_status'      => $result['starch_status'],
      'result_ndf_status'         => $result['ndf_status'],
      'result_heat_stress'        => $result['heat_stress'],
      'result_symptoms_observed'  => $result['symptoms_observed'] ? '1' : '0',
      'result_buffer_status'      => $result['buffer_status'],
      // ── Dynamic messages (JSON-encoded array of blocks) ───────────────
      'result_dynamic_messages'   => json_encode($result['dynamic_messages'], JSON_UNESCAPED_UNICODE),
      // ── Timestamp ─────────────────────────────────────────────────────
      'result_calculated_at'      => date('Y-m-d H:i:s'),
    ]);

    $webform_submission->setData($stored_data);

    // Re-save without re-triggering this handler.
    if (!$update) {
      $webform_submission->resave();
    }
    else {
      \Drupal::entityTypeManager()
        ->getStorage('webform_submission')
        ->save($webform_submission);
    }
  }

  /**
   * {@inheritdoc}
   * Redirect to our custom results page after successful submission.
   */
  public function confirmForm(
    array &$form,
    FormStateInterface $form_state,
    WebformSubmissionInterface $webform_submission
  ): void {
    $form_state->setRedirect(
      'solvay_acidosis_calculator.results',
      ['webform_submission' => $webform_submission->id()]
    );
  }

  public function buildConfigurationForm(array $form, FormStateInterface $form_state): array {
    return $form;
  }

  public function getSummary(): array {
    return [
      '#markup' => $this->t('Calculates acidosis risk score, dynamic contextual messages, and Bicar®Z dosage recommendation.'),
    ];
  }

}
