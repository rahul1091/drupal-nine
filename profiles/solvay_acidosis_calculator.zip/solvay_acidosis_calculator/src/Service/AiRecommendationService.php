<?php

namespace Drupal\solvay_acidosis_calculator\Service;

use GuzzleHttp\ClientInterface;
use Psr\Log\LoggerInterface;
use Psr\Log\LoggerAwareTrait;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;

/**
 * Calls an AI provider to refine the rule-based Bicar®Z dosage and generate
 * a plain-language explanation plus prioritized ration adjustments for the
 * results page.
 *
 * Design principles:
 *  - The rule-based score/dosage band (computed by AcidosisCalculatorService
 *    and stored on the webform submission) always remains the source of
 *    truth. This service only REFINES the dosage within that band and adds
 *    explanatory text — it never overrides the underlying risk assessment.
 *  - Any failure (network error, timeout, malformed response, dosage out
 *    of bounds) results in NULL being returned, never an exception bubbling
 *    up to the caller. The results page must always work even if this
 *    service / the AI provider is unavailable.
 *  - Results are cached per submission ID so repeat page views don't
 *    re-trigger API calls (cost + latency control).
 */
class AiRecommendationService {

  public function __construct(
    protected ClientInterface $httpClient,
    protected ConfigFactoryInterface $configFactory,
    protected CacheBackendInterface $cache,
    protected LoggerChannelFactoryInterface $loggerFactory,
  ) {}

  /**
   * Returns a refined recommendation, or NULL if unavailable/failed.
   *
   * @param int $submission_id
   *   The webform submission ID, used as the cache key.
   * @param array $inputs
   *   The farmer's original ration/form inputs (concentrates, forages,
   *   buffer already fed, symptoms observed, etc.) — NOT the computed
   *   result_* fields.
   * @param array $ruleBasedResult
   *   Must contain: 'score' (float), 'risk_level' (string),
   *   'dosage_min' (int), 'dosage_max' (int) — the guardrail band the AI's
   *   refined dosage must stay within.
   *
   * @return array|null
   *   ['refined_dosage_g' => int, 'explanation' => string,
   *   'adjustments' => string[]], or NULL on failure/disabled.
   */
  public function getRecommendation(int $submission_id, array $inputs, array $ruleBasedResult): ?array {
    $logger = $this->loggerFactory->get('solvay_acidosis_calculator');

    $cid = 'solvay_acidosis_calculator:ai_rec:' . $submission_id;
    $cached = $this->cache->get($cid);
    if ($cached) {
      return $cached->data;
    }

    $config = $this->configFactory->get('solvay_acidosis_calculator.settings');
    if (!$config->get('ai_enabled')) {
      return NULL;
    }

    $endpoint = $config->get('api_endpoint');
    $api_key  = $this->resolveApiKey($config->get('api_key'));
    if (!$endpoint || !$api_key) {
      $logger->warning('AI recommendation skipped: endpoint or API key not configured.');
      return NULL;
    }

    try {
      $prompt = $this->buildPrompt($inputs, $ruleBasedResult);

      $response = $this->httpClient->post($endpoint, [
        'headers' => [
          'x-api-key'         => $api_key,
          'anthropic-version' => '2023-06-01',
          'content-type'      => 'application/json',
        ],
        'json' => [
          'model'      => $config->get('model') ?: 'claude-sonnet-4-6',
          'max_tokens' => 500,
          'messages'   => [
            ['role' => 'user', 'content' => $prompt],
          ],
        ],
        'timeout' => (int) ($config->get('timeout') ?? 8),
      ]);

      $body = (string) $response->getBody();
      $data = json_decode($body, TRUE);
      $text = $data['content'][0]['text'] ?? '';

      $parsed = json_decode(trim($text), TRUE);
      if (json_last_error() !== JSON_ERROR_NONE || empty($parsed)) {
        throw new \RuntimeException('Malformed AI response body: ' . substr($body, 0, 500));
      }

      $result = $this->validateAndClamp($parsed, $ruleBasedResult);
      if ($result === NULL) {
        throw new \RuntimeException('AI response failed validation: ' . substr($text, 0, 500));
      }

      // Cache for 24 hours — a submission's inputs/results don't change,
      // so there's no reason to re-call the API on repeat page views.
      $this->cache->set($cid, $result, time() + 86400);

      return $result;
    }
    catch (\Throwable $e) {
      $logger->warning('AI recommendation failed for submission @id: @msg', [
        '@id'  => $submission_id,
        '@msg' => $e->getMessage(),
      ]);
      return NULL;
    }
  }

  /**
   * Validates the AI's parsed JSON response and clamps the refined dosage
   * to the rule-based guardrail band. Returns NULL if the response is
   * missing required keys or is structurally unusable.
   */
  protected function validateAndClamp(array $parsed, array $ruleBasedResult): ?array {
    if (!isset($parsed['explanation'], $parsed['adjustments'], $parsed['refined_dosage_g'])) {
      return NULL;
    }
    if (!is_array($parsed['adjustments'])) {
      return NULL;
    }

    $min = $ruleBasedResult['dosage_min'] ?? NULL;
    $max = $ruleBasedResult['dosage_max'] ?? NULL;
    $dosage = (int) $parsed['refined_dosage_g'];

    // Hard guardrail: never let the AI's dosage escape the rule-based
    // band, regardless of what it returned. Clamp rather than reject
    // outright, since a slightly-out-of-range value is still usable once
    // bounded.
    if ($min !== NULL && $dosage < $min) {
      $dosage = $min;
    }
    if ($max !== NULL && $dosage > $max) {
      $dosage = $max;
    }

    return [
      'refined_dosage_g' => $dosage,
      'explanation'      => (string) $parsed['explanation'],
      // Cap at 3 adjustments and force to strings, in case the model
      // returns something unexpected in the array.
      'adjustments'      => array_map('strval', array_slice($parsed['adjustments'], 0, 3)),
    ];
  }

  /**
   * Resolves the configured API key value into the actual secret.
   *
   * If the Key module is installed, $configured_value is a Key entity ID
   * and the real secret is fetched from it (env var / secrets manager,
   * never stored in exported config). Otherwise $configured_value is
   * treated as the raw key (see AiSettingsForm's fallback + warning for
   * that case).
   */
  protected function resolveApiKey(?string $configured_value): ?string {
    if (!$configured_value) {
      return NULL;
    }
    if (\Drupal::moduleHandler()->moduleExists('key')) {
      /** @var \Drupal\key\KeyRepositoryInterface $key_repository */
      $key_repository = \Drupal::service('key.repository');
      $key_entity = $key_repository->getKey($configured_value);
      return $key_entity ? $key_entity->getKeyValue() : NULL;
    }
    return $configured_value;
  }

  /**
   * Builds the prompt sent to the AI provider. Explicitly instructs the
   * model to return ONLY JSON (no markdown fences, no preamble) and to
   * stay within the rule-based dosage band.
   */
  protected function buildPrompt(array $inputs, array $ruleBasedResult): string {
    $inputs_json = json_encode($inputs, JSON_UNESCAPED_SLASHES);
    $min = $ruleBasedResult['dosage_min'] ?? 0;
    $max = $ruleBasedResult['dosage_max'] ?? 0;
    $score = $ruleBasedResult['score'] ?? 0;
    $risk_level = $ruleBasedResult['risk_level'] ?? '';

    return <<<PROMPT
    You are a dairy nutrition assistant helping interpret a ruminal acidosis risk calculator result for a farmer. Respond with ONLY valid JSON — no markdown code fences, no preamble, no explanation outside the JSON object. The JSON object must have exactly these keys:
    - "refined_dosage_g": integer, MUST be between {$min} and {$max} inclusive.
    - "explanation": a 1-2 sentence plain-language explanation of the main factors driving this risk score, written for a farmer (not a vet).
    - "adjustments": an array of 2-3 short, concrete, prioritized ration adjustments the farmer could make to reduce risk.

    Ration inputs (JSON): {$inputs_json}
    Computed risk score (0-5 scale): {$score}
    Risk level: {$risk_level}
    Rule-based recommended dosage band (grams/day): {$min}-{$max}
    PROMPT;
  }

}
