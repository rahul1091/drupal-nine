<?php

namespace Drupal\solvay_acidosis_calculator\Service;

use Drupal\Core\Logger\LoggerChannelFactoryInterface;

/**
 * Calculates ruminal acidosis risk score and Bicar®Z dosage recommendation.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * CALCULATION LOGIC
 * ─────────────────────────────────────────────────────────────────────────
 * This service is a PHP port of the calculation engine found in the
 * official Bicar®Z Angular application (bicarz-ui, src/app/app.component.ts
 * + src/app/models.ts). It replaces the earlier simplified "acid load
 * score" heuristic with the same rumen-pH prediction model used by the
 * Angular tool, so that the Drupal webform produces identical results
 * (dry substance, starch %, NDF %, predicted average rumen pH, sub-acute
 * acidosis risk index 0–5, recommended Bicar®Z dose in g/cow/day, and
 * estimated milk fat with/without supplementation).
 *
 * High level steps (mirrors AppComponent.calculate() in the Angular app):
 *  1. Every feed ingredient is looked up in $nutritionData for its default
 *     nutrient composition (dry matter %, starch %, NDF %, physically
 *     effective NDF %, ADF %, in-situ starch degradability (ISSD), starch
 *     degradation rate (Kd), passage rate (Kp) and buffering power (Pt)).
 *  2. Ingredients are split into two groups exactly like the Angular app:
 *     "concentrates" (low starch food, nucleus/soya, corn, high starch
 *     diet, corn/barley flakes, and mash) and "forages" (silomais, sorgum
 *     silage, other baleage, alfalfa, other hay, straw).
 *  3. Dry-matter-weighted totals/averages are computed per group, then
 *     combined into a set of "calculation basis" values (rumen fill,
 *     digested DMI, rumen degradable starch, peNDF, ADF, buffering
 *     power, etc.) — see computeCalculationBasis().
 *  4. Twelve independent empirical sub-models predict rumen pH from
 *     different angles (VFA production, ISSD, rumen starch, NDF, grain
 *     size, starch %, digestibility, DMI/BW, peNDF, ADF, buffering power,
 *     forage NDF). The four lowest (= most acidic) predictions are
 *     averaged — see computeSystemEquations().
 *  5. That average is adjusted for heat stress and combined into the
 *     final "predicted average rumen pH" ($medium).
 *  6. The rumen-acidosis risk index (0–5) and Bicar®Z dosage are derived
 *     from $medium, dry matter intake, existing buffer already fed, and
 *     whether acidosis symptoms were observed — see resultCalculation().
 *
 * Dynamic message system
 * ──────────────────────
 * The results page shows a multi-part contextual message assembled from
 * several independent signal blocks, each driven by a different form
 * input or calculated value. Each block is returned as a separate key in
 * the calculate() result so the Twig template can render them
 * individually with their own styles.
 */
class AcidosisCalculatorService
{

  protected $logger;

  /**
   * Nutritional composition per kg as-fed for each feed ingredient.
   *
   * Values are ported 1:1 from the Angular app's default models
   * (src/app/models.ts):
   *   dm     = dry matter fraction (0–1)   [Angular: drySubstance, %]
   *   starch = starch, % of DM             [Angular: starch]
   *   ndf    = NDF, % of DM                [Angular: ndf]
   *   pendf  = physically effective NDF, % of the ingredient's NDF
   *            [Angular: peNdf]
   *   adf    = ADF, % of DM                [Angular: adf]
   *   issd   = in-situ starch degradability index [Angular: issd]
   *   kd     = rumen degradation rate      [Angular: kd]
   *   kp     = rumen passage rate          [Angular: kp]
   *   pt     = buffering power index       [Angular: pt]
   *   group  = 'concentrate' or 'forage' — determines which sub-totals
   *            (sumOfConcentrates / sumOfForages in the Angular app) the
   *            ingredient feeds into. Note "mash" is a silage but is
   *            grouped with the concentrates, exactly as in the Angular
   *            app (section2 && fieldName == 'mash' => sumOfConcentrates).
   *
   * NOTE: for 'silomais' the 'pendf' value is dynamically overridden
   * according to the forage cutting length, exactly like
   * AppComponent.setCuttingLength() in the Angular app — see
   * computeRation().
   */
  protected array $nutritionData = [
    // Concentrates
    'low_starch_food'    => ['dm' => 0.87,  'starch' => 23, 'ndf' => 20, 'pendf' => 30, 'adf' => 14,   'issd' => 50, 'kd' => 0.2,   'kp' => 0.07,  'pt' => 2,   'group' => 'concentrate'],
    'nucleus_soya'       => ['dm' => 0.87,  'starch' =>  5, 'ndf' => 20, 'pendf' => 30, 'adf' => 14,   'issd' => 50, 'kd' => 0.2,   'kp' => 0.07,  'pt' => 3,   'group' => 'concentrate'],
    'corn'               => ['dm' => 0.87,  'starch' => 65, 'ndf' =>  8, 'pendf' => 30, 'adf' =>  8,   'issd' => 35, 'kd' => 0.16,  'kp' => 0.07,  'pt' => 2,   'group' => 'concentrate'],
    'high_starch_diet'   => ['dm' => 0.87,  'starch' => 40, 'ndf' =>  8, 'pendf' => 30, 'adf' =>  8,   'issd' => 60, 'kd' => 0.22,  'kp' => 0.07,  'pt' => 2,   'group' => 'concentrate'],
    'corn_barley_flakes' => ['dm' => 0.87,  'starch' => 63, 'ndf' =>  9, 'pendf' => 30, 'adf' =>  8,   'issd' => 65, 'kd' => 0.25,  'kp' => 0.07,  'pt' => 0,   'group' => 'concentrate'],
    // Silage (mash is grouped with concentrates, matching the Angular app)
    'mash'               => ['dm' => 0.65,  'starch' => 58, 'ndf' => 20, 'pendf' => 30, 'adf' =>  8,   'issd' => 55, 'kd' => 0.2,   'kp' => 0.07,  'pt' => -3,  'group' => 'concentrate'],
    'silomais'           => ['dm' => 0.33,  'starch' => 30, 'ndf' => 48, 'pendf' => 70, 'adf' => 25,   'issd' => 40, 'kd' => 0.06,  'kp' => 0.052, 'pt' => -5,  'group' => 'forage'],
    'sorgum_silage'      => ['dm' => 0.26,  'starch' =>  5, 'ndf' => 60, 'pendf' => 80, 'adf' => 36,   'issd' => 20, 'kd' => 0.06,  'kp' => 0.052, 'pt' => 5,   'group' => 'forage'],
    'other_baleage'      => ['dm' => 0.28,  'starch' =>  5, 'ndf' => 65, 'pendf' => 85, 'adf' => 35,   'issd' =>  0, 'kd' => 0.04,  'kp' => 0.052, 'pt' => 5,   'group' => 'forage'],
    // Hay
    'alfalfa'            => ['dm' => 0.87,  'starch' =>  0, 'ndf' => 48, 'pendf' => 85, 'adf' => 36,   'issd' =>  0, 'kd' => 0.035, 'kp' => 0.043, 'pt' => 25,  'group' => 'forage'],
    'other_hay'          => ['dm' => 0.87,  'starch' =>  0, 'ndf' => 56, 'pendf' => 90, 'adf' => 35,   'issd' =>  0, 'kd' => 0.04,  'kp' => 0.043, 'pt' => 15,  'group' => 'forage'],
    'straw'              => ['dm' => 0.925, 'starch' =>  0, 'ndf' => 73, 'pendf' => 95, 'adf' => 48,   'issd' =>  0, 'kd' => 0.04,  'kp' => 0.035, 'pt' => 12,  'group' => 'forage'],
  ];

  /**
   * Sub-acute acidosis risk index (0–5) thresholds, identical to the
   * Angular app's sideHeaders logic in resultCalculation():
   *   < 1.53          → low risk    (SIDE_HEADER_4)
   *   1.53 – < 3.39    → medium risk (SIDE_HEADER_5)
   *   >= 3.39          → high risk   (SIDE_HEADER_6)
   */
  protected array $thresholds = ['low' => 1.53, 'medium' => 3.39];

  public function __construct(LoggerChannelFactoryInterface $loggerFactory)
  {
    $this->logger = $loggerFactory->get('solvay_acidosis_calculator');
  }

  /** Returns nutrition data for the JS live-footer. */
  public function getNutritionData(): array
  {
    return $this->nutritionData;
  }

  /**
   * Decodes and merges the two per-page "nutrition overrides" hidden fields
   * (page_1_nutrition_overrides, page_2_nutrition_overrides) into a single
   * [field => ['dm' => float, 'starch' => float, 'ndf' => float]] map.
   *
   * These fields are written client-side (js/ruminal-acidosis-calculator.js)
   * whenever the user updates an ingredient's values via the "+" popup —
   * mirroring the Angular app's calculator-popup, which lets the user
   * override an ingredient's Dry Substance / Starch / NDF. Both hidden
   * fields are kept in sync with the *same* full JSON blob by the client,
   * so in practice either one alone is sufficient — merging both here is
   * just a defensive safety net in case only one page was ever visited.
   *
   * Dry Substance is stored by the client as a 0–1 fraction (matching
   * $this->nutritionData's 'dm' key), even though the popup itself
   * displays/edits it as a whole percentage (e.g. "87").
   */
  protected function parseNutritionOverrides(array $values): array {
    $merged = [];
    foreach (['page_1_nutrition_overrides', 'page_2_nutrition_overrides'] as $key) {
      if (empty($values[$key]) || !is_string($values[$key])) continue;
      $decoded = json_decode($values[$key], TRUE);
      if (is_array($decoded)) {
        $merged = array_merge($merged, $decoded);
      }
    }
    return $merged;
  }

  // ══════════════════════════════════════════════════════════════════════════
  // PUBLIC: MAIN CALCULATION
  // ══════════════════════════════════════════════════════════════════════════

  /**
   * Runs the full calculation and returns every value needed by the results page.
   */
  public function calculate(array $values): array {
    $symptoms = !empty($values['acidosis_symptoms']) && $values['acidosis_symptoms'] === 'yes';
    $length   = $values['forage_cutting_length']     ?? 'short';
    $temp     = $values['environmental_temperature'] ?? 'normal';

    $nahco3_existing = (float) ($values['sodium_bicarbonate'] ?? 0);
    $mgo_existing    = (float) ($values['magnesium_oxide']    ?? 0);

    // Merge any per-ingredient Dry Substance / Starch / NDF overrides set
    // via the "+" popup (mirrors the Angular app's calculator-popup). These
    // are carried across the wizard's pages as JSON in two hidden fields —
    // one per page, since a Drupal webform element must live on a single
    // wizard page — and only ever affect dm/starch/ndf; every other
    // nutrient value (adf, pendf, issd, kd, kp, pt) always comes from the
    // built-in defaults in $this->nutritionData.
    $overrides = $this->parseNutritionOverrides($values);

    // Step 1-3: per-ingredient totals, concentrate/forage grouping.
    $ration = $this->computeRation($values, $length, $overrides);

    // Step 3-4: calculation basis + the twelve rumen-pH sub-models.
    $basis      = $this->computeCalculationBasis($ration, $nahco3_existing, $mgo_existing);
    $equations  = $this->computeSystemEquations($basis);
    $medium     = $this->computeMedium($equations, $temp);

    // Step 5-6: risk index, Bicar®Z dosage, estimated milk fat.
    $result = $this->resultCalculation($medium, $basis, $symptoms, $nahco3_existing, $mgo_existing);

    $score = $result['sub_acidosis_risk'];

    [$risk_level, $risk_label, $panel_color] = $this->classifyRisk($score);

    // ── Derived signal statuses (drive dynamic messages) ──────────────────
    $starch_status  = $this->classifyStarch($ration['starch_percent']);
    $ndf_status     = $this->classifyNdf($ration['ndf_percent']);
    $heat_stress    = $this->classifyHeatStress($temp);
    $buffer_status  = $this->classifyBuffer($nahco3_existing, $mgo_existing);

    // ── Assemble all dynamic message blocks ───────────────────────────────
    $dynamic_messages = $this->buildDynamicMessages(
      $risk_level,
      $risk_label,
      $score,
      $ration['starch_percent'],
      $ration['ndf_percent'],
      $starch_status,
      $ndf_status,
      $heat_stress,
      $symptoms,
      $buffer_status,
      $result['recommended_dosage'],
      $length
    );

    $this->logger->info(
      'Acidosis: risk=@s level=@l starch=@st ndf=@n dosage=@d fat=@f heat=@h symptoms=@sy',
      [
        '@s'  => round($score, 2),
        '@l'  => $risk_level,
        '@st' => round($ration['starch_percent'], 1),
        '@n'  => round($ration['ndf_percent'], 1),
        '@d'  => $result['recommended_dosage'],
        '@f'  => $result['estimated_fat'],
        '@h'  => $temp,
        '@sy' => $symptoms ? 'yes' : 'no',
      ]
    );

    return [
      'risk_score'         => round($score, 2),
      'risk_level'         => $risk_level,
      'risk_label'         => $risk_label,
      'recommended_dosage' => $result['recommended_dosage'],
      'estimated_fat'      => $result['estimated_fat'],
      'dry_substance'      => round($ration['dry_substance'], 2),
      'starch_percent'     => round($ration['starch_percent'], 2),
      'ndf_percent'        => round($ration['ndf_percent'], 2),
      'cow_message'        => $this->getCowMessage($risk_level),
      'panel_color'        => $panel_color,
      // New keys
      'dynamic_messages'   => $dynamic_messages,
      'starch_status'      => $starch_status,
      'ndf_status'         => $ndf_status,
      'heat_stress'        => $heat_stress,
      'symptoms_observed'  => $symptoms,
      'buffer_status'      => $buffer_status,
    ];
  }

  // ══════════════════════════════════════════════════════════════════════════
  // PRIVATE: RATION TOTALS (Angular: summarizeCalculatedValues / getSummaraizedVales / getSumOfConcentrateandForages)
  // ══════════════════════════════════════════════════════════════════════════

  /**
   * Computes dry-matter totals and concentrate/forage group sub-totals.
   *
   * Mirrors AppComponent.calculateRationValues() + getSummaraizedVales() +
   * getSumOfConcentrateandForages() from the Angular app.
   */
  protected function computeRation(array $values, string $forage_length, array $overrides = []): array {
    // AppComponent.setCuttingLength(): silomais peNDF depends on the forage
    // cutting length select. (non_uniform_length isn't exposed in this
    // Drupal form, only short/medium/long.)
    $silomais_pendf = match ($forage_length) {
      'short' => 60,
      'medium' => 70,
      'long'  => 75,
      default => 60, // short
    };

    // getSumOfConcentrateandForages(): pendfforage multiplier applied only
    // to the forage group, based on forage cutting length.
    $cutting_factor = match ($forage_length) {
      'short' => 0.8,
      'medium' => 1.0,
      'long'  => 1.1,
      default => 0.8, // short
    };

    $total_dm = $total_starch_kg = $total_ndf_kg = 0.0;

    $conc = ['dm' => 0.0, 'starch' => 0.0, 'ndf' => 0.0, 'pendf' => 0.0, 'adf' => 0.0, 'issd_sum' => 0.0, 'kd_sum' => 0.0, 'kp_sum' => 0.0, 'pt_sum' => 0.0];
    $for  = ['dm' => 0.0, 'starch' => 0.0, 'ndf' => 0.0, 'pendf' => 0.0, 'adf' => 0.0, 'issd_sum' => 0.0, 'kd_sum' => 0.0, 'kp_sum' => 0.0, 'pt_sum' => 0.0, 'pendfforage' => 0.0];

    foreach ($this->nutritionData as $field => $data) {
      $qty = (float) ($values[$field] ?? 0);
      if ($qty <= 0) continue;

      // Apply any user override (from the "+" popup) for this ingredient's
      // Dry Substance / Starch / NDF. All other nutrient fields (adf, pendf,
      // issd, kd, kp, pt) always come from the built-in defaults.
      if (!empty($overrides[$field]) && is_array($overrides[$field])) {
        $o = $overrides[$field];
        if (isset($o['dm'])     && is_numeric($o['dm']))     $data['dm']     = (float) $o['dm'];
        if (isset($o['starch']) && is_numeric($o['starch'])) $data['starch'] = (float) $o['starch'];
        if (isset($o['ndf'])    && is_numeric($o['ndf']))    $data['ndf']    = (float) $o['ndf'];
      }

      $pendf_pct = ($field === 'silomais') ? $silomais_pendf : $data['pendf'];

      $kg_dm     = $qty * $data['dm'];                         // Angular: qty * ds * 0.01
      $starch_kg = $kg_dm * ($data['starch'] / 100);            // Angular: qty * starch * ds * 0.0001
      $ndf_kg    = $kg_dm * ($data['ndf']    / 100);            // Angular: qty * ndf    * ds * 0.0001
      $adf_kg    = $kg_dm * ($data['adf']    / 100);            // Angular: qty * adf    * ds * 0.0001
      $pendf_kg  = $ndf_kg * ($pendf_pct / 100);                // Angular: ndf_kg * peNdf * 0.01
      $issd_kg   = $kg_dm * $data['issd'];                      // Angular: qty * ds * 0.01 * issd
      $kd_kg     = $kg_dm * $data['kd'];
      $kp_kg     = $kg_dm * $data['kp'];
      $pt_kg     = $kg_dm * $data['pt'];

      $total_dm        += $kg_dm;
      $total_starch_kg += $starch_kg;
      $total_ndf_kg    += $ndf_kg;

      $group = ($data['group'] === 'concentrate') ? $conc : $for;
      $group['dm']       += $kg_dm;
      $group['starch']   += $starch_kg;
      $group['ndf']      += $ndf_kg;
      $group['pendf']    += $pendf_kg;
      $group['adf']      += $adf_kg;
      $group['issd_sum'] += $issd_kg;
      $group['kd_sum']   += $kd_kg;
      $group['kp_sum']   += $kp_kg;
      $group['pt_sum']   += $pt_kg;

      if ($data['group'] === 'forage') {
        $group['pendfforage'] += $pendf_kg * $cutting_factor;
      }

      if ($data['group'] === 'concentrate') {
        $conc = $group;
      }
      else {
        $for = $group;
      }
    }

    // Angular's multiplyValues(): issd is divided by the TOTAL ration DM
    // (not the group-only DM) — a quirk of the original spreadsheet model
    // that we replicate exactly. Kd/Kp/Pt are divided by the group's own DM.
    $conc_issd = $total_dm > 0 ? $conc['issd_sum'] / $total_dm : 0.0;
    $for_issd  = $total_dm > 0 ? $for['issd_sum']  / $total_dm : 0.0;
    $conc_kd   = $conc['dm'] > 0 ? $conc['kd_sum'] / $conc['dm'] : 0.0;
    $conc_kp   = $conc['dm'] > 0 ? $conc['kp_sum'] / $conc['dm'] : 0.0;
    $conc_pt   = $conc['dm'] > 0 ? $conc['pt_sum'] / $conc['dm'] : 0.0;
    $for_kd    = $for['dm']  > 0 ? $for['kd_sum']  / $for['dm']  : 0.0;
    $for_kp    = $for['dm']  > 0 ? $for['kp_sum']  / $for['dm']  : 0.0;
    $for_pt    = $for['dm']  > 0 ? $for['pt_sum']  / $for['dm']  : 0.0;

    return [
      'dry_substance'   => $total_dm,
      'starch_percent'  => $total_dm > 0 ? ($total_starch_kg / $total_dm) * 100 : 0.0,
      'ndf_percent'     => $total_dm > 0 ? ($total_ndf_kg    / $total_dm) * 100 : 0.0,
      'conc_dm'         => $conc['dm'],
      'conc_starch_kg'  => $conc['starch'],
      'conc_ndf_kg'     => $conc['ndf'],
      'conc_pendf_kg'   => $conc['pendf'],
      'conc_adf_kg'     => $conc['adf'],
      'conc_issd'       => $conc_issd,
      'conc_kd'         => $conc_kd,
      'conc_kp'         => $conc_kp,
      'conc_pt'         => $conc_pt,
      'for_dm'          => $for['dm'],
      'for_starch_kg'   => $for['starch'],
      'for_ndf_kg'      => $for['ndf'],
      'for_pendf_kg'    => $for['pendf'],
      'for_adf_kg'      => $for['adf'],
      'for_pendfforage_kg' => $for['pendfforage'],
      'for_issd'        => $for_issd,
      'for_kd'          => $for_kd,
      'for_kp'          => $for_kp,
      'for_pt'          => $for_pt,
    ];
  }

  // ══════════════════════════════════════════════════════════════════════════
  // PRIVATE: CALCULATION BASIS (Angular: calculateBasics())
  // ══════════════════════════════════════════════════════════════════════════

  protected function computeCalculationBasis(array $ration, float $nahco3, float $mgo): array {
    $dmi = $ration['dry_substance']; // ac38
    $bw  = 659.0;                    // ac (fixed body weight, matches Angular)

    $kd_ration = $dmi > 0
      ? ($ration['conc_kd'] * $ration['conc_dm'] / $dmi) + ($ration['for_kd'] * $ration['for_dm'] / $dmi)
      : 0.0; // ac40
    $kp_ration = $dmi > 0
      ? ($ration['conc_kp'] * $ration['conc_dm'] / $dmi) + ($ration['for_kp'] * $ration['for_dm'] / $dmi)
      : 0.0; // ac41

    $digested_dmi = ($kd_ration + $kp_ration) > 0
      ? $dmi * ($kd_ration / ($kd_ration + $kp_ration))
      : 0.0; // ac42

    $agv1 = 8.03 * $digested_dmi + 8.9; // ac43/ac44

    $issd = $ration['conc_issd'] + $ration['for_issd']; // ac45

    $sum_kd_kp = $ration['conc_kd'] + ($ration['conc_kp'] > 0 ? $ration['conc_kp'] : 0); // helper
    $rumen_st  = $sum_kd_kp > 0
      ? ($ration['conc_starch_kg'] + $ration['for_starch_kg']) * ($ration['conc_kd'] / $sum_kd_kp)
      : 0.0; // ac48

    $pe_ndf = $dmi > 0
      ? (($ration['conc_pendf_kg'] + $ration['for_pendfforage_kg']) / $dmi) * 100
      : 0.0; // ac51 (U value)

    $f_ndf = $dmi > 0 ? ($ration['for_ndf_kg'] / $dmi) * 100 : 0.0;             // ac52
    $fpe_ndf = $dmi > 0 ? ($ration['for_pendfforage_kg'] / $dmi) * 100 : 0.0;   // ac53

    $adf = $dmi > 0
      ? (($ration['conc_adf_kg'] + $ration['for_adf_kg']) / $dmi) * 100 * 1.02
      : 0.0; // ac54

    $grain_size    = 2.0;  // ac56 (fixed, matches Angular)
    $power_buffer  = $ration['conc_pt'] + $ration['for_pt']; // ac58 ("Z" value)

    return [
      'bw'            => $bw,
      'dmi'           => $dmi,
      'kd_ration'     => $kd_ration,
      'kp_ration'     => $kp_ration,
      'digested_dmi'  => $digested_dmi,
      'agv1'          => $agv1,
      'issd'          => $issd,
      'rumen_st'      => $rumen_st,
      'starchration'  => $ration['starch_percent'], // ac49
      'ndfration'     => $ration['ndf_percent'],    // ac50
      'pe_ndf'        => $pe_ndf,
      'f_ndf'         => $f_ndf,
      'fpe_ndf'       => $fpe_ndf,
      'adf'           => $adf,
      'grain_size'    => $grain_size,
      'power_buffer'  => $power_buffer,
    ];
  }

  // ══════════════════════════════════════════════════════════════════════════
  // PRIVATE: THE TWELVE RUMEN-pH SUB-MODELS (Angular: calculateSystemEquations())
  // ══════════════════════════════════════════════════════════════════════════

  /**
   * @return float[] Twelve predicted rumen pH values (index 0-11). Index 11
   *   corresponds to the forage-NDF equation and is treated specially by
   *   computeMedium(), exactly like the Angular app's findMinValues().
   */
  protected function computeSystemEquations(array $b): array {
    $safe_div = fn(float $num, float $den): float => $den != 0.0 ? $num / $den : 0.0;

    $equations = [
      6.96 - 0.007 * $b['agv1'],                                                     // 0  ac61
      6.18 - 0.004 * $b['issd'],                                                     // 1  ac62
      6.4  - $safe_div($b['rumen_st'], $b['dmi']) * 100 * 0.02,                      // 2  ac63
      5.25 + 0.025 * $b['ndfration'],                                                // 3  ac64
      5.14 + 0.57 * $b['grain_size'] - 0.068 * $b['grain_size'] * $b['grain_size'],   // 4  ac65
      $b['starchration'] * -0.1 + 8.75,                                              // 5  ac66
      7.12 - 0.014 * $safe_div($b['digested_dmi'], $b['dmi']) * 100,                  // 6  ac68
      6.8  - 0.21 * $safe_div($b['dmi'], $b['bw']) * 100,                             // 7  ac69
      6.67 - 14.3 * $safe_div(1.0, $b['fpe_ndf']),                                    // 8  ac70
      5.34 + 0.056 * $b['adf'],                                                       // 9  ac71
      5.68 + 0.056 * $b['power_buffer'],                                              // 10 ac72
      4.06 + 0.0855 * $b['f_ndf'],                                                    // 11 ac73 (forage NDF eq.)
    ];

    // Angular: replace NaN with 0. We also normalise +/-INF for safety.
    foreach ($equations as &$e) {
      if (!is_finite($e)) $e = 0.0;
    }
    unset($e);

    return $equations;
  }

  /**
   * Angular: findMinValues() + calculateMedium().
   *
   * Averages the four lowest (most acidic) of the twelve predicted pH
   * values, EXCLUDING the forage-NDF equation (last index) from the
   * average if it happens to be one of the four lowest — it still "uses up"
   * one of the four slots but doesn't contribute to the sum, exactly
   * matching the Angular app's behaviour. The result is then adjusted for
   * heat stress and converted from an average-pH deviation into the
   * predicted average rumen pH.
   */
  protected function computeMedium(array $equations, string $temperature): float {
    $last_index = count($equations) - 1;

    $sorted_keys = $equations;
    asort($sorted_keys); // sort by value, ascending, preserve original keys
    $min_keys = array_slice(array_keys($sorted_keys), 0, 4, TRUE);

    $total = 0.0;
    $count = 0;
    foreach ($min_keys as $key) {
      if ($key !== $last_index) {
        $total += $equations[$key];
        $count++;
      }
    }

    $avg = $count > 0 ? $total / $count : 0.0;

    // Angular calculateMedium(): environmentalTemperature adjustment.
    // Drupal's 3-tier scale (normal < 25°C / warm 25-28°C / hot > 28°C) is
    // mapped onto the Angular app's three tiers (normal / hot / hot_and_humid)
    // in increasing order of severity, using the same numeric constants.
    $adjustment = match ($temperature) {
      'normal' => 0.0,
      'hot'   => -0.02,  // Angular "hot" tier
      'hot_and_humid'    => -0.05,  // Angular "hot_and_humid" tier
      default  => 0.0,
    };

    return 57 - 9 * ($avg + $adjustment);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // PRIVATE: RISK INDEX, DOSAGE & FAT ESTIMATE (Angular: resultCalculation())
  // ══════════════════════════════════════════════════════════════════════════

  protected function resultCalculation(
    float $medium,
    array $basis,
    bool $symptoms,
    float $nahco3_existing,
    float $mgo_existing
  ): array {
    $risk_base = (-0.4734 + 0.5244 * $medium - 0.0333493 * $medium * $medium) * 10 * $basis['dmi'];
    $risk_equation = $symptoms ? $risk_base * 1.2 : $risk_base;

    $existing_buffer = $nahco3_existing + 0.33 * $mgo_existing;

    if ($existing_buffer > $risk_equation) {
      $sub_acidosis_risk = 0.0;
      $estimated_step    = 0.0;
    }
    else {
      $sub_acidosis_risk = $risk_equation != 0.0
        ? $medium * (1 - $existing_buffer * (1 / $risk_equation))
        : 0.0;
      $estimated_step = $risk_equation - $existing_buffer;
    }

    $adf = $basis['adf'];

    // Estimated milk fat from the CURRENT ration (existing buffer only).
    $estimated_adf = (
      2.49
      + 0.056 * $adf
      + 0.00242 * $nahco3_existing
      + 0.00547 * $mgo_existing
      - 0.0000812 * $adf * $nahco3_existing
      - 0.000184  * $adf * $mgo_existing
      - 0.0000053 * $nahco3_existing * $mgo_existing
    ) * 10;

    $recommended_dose = min(max($estimated_step, 0.0), 290.0);
    $recommended_diet = $nahco3_existing + $estimated_step;

    // Estimated milk fat WITH the recommended additional Bicar®Z dose.
    $with_bicarbonate = (
      2.49
      + 0.056 * $adf
      + 0.00242 * $recommended_diet
      + 0.00547 * $mgo_existing
      - 0.0000812 * $adf * $recommended_diet
      - 0.000184  * $adf * $mgo_existing
      - 0.0000053 * $recommended_diet * $mgo_existing
    ) * 10;

    $correction_no_bicarb   = min($estimated_adf, 42.0);
    $correction_with_bicarb = min($with_bicarbonate, 42.0);

    $fat_estimated_from_ration     = $correction_no_bicarb * 0.1;
    $fat_estimated_with_bicarbonate = round($correction_with_bicarb * 0.1, 2);

    $sub_acidosis_risk = max(0.0, min($sub_acidosis_risk, 5.0));

    return [
      'sub_acidosis_risk'    => $sub_acidosis_risk,
      'recommended_dosage'   => round($recommended_dose, 0),
      'estimated_fat'        => $fat_estimated_with_bicarbonate,
      'estimated_fat_no_buf' => round($fat_estimated_from_ration, 2),
    ];
  }

  // ══════════════════════════════════════════════════════════════════════════
  // PRIVATE: SIGNAL CLASSIFIERS
  // ══════════════════════════════════════════════════════════════════════════

  /**
   * Overall risk banding on the 0–5 sub-acidosis risk index, matching the
   * Angular app's sideHeaders thresholds exactly (1.53 / 3.39).
   */
  protected function classifyRisk(float $score): array
  {
    if ($score < $this->thresholds['low'])    return ['low',    'Low Risk',    '#4caf50'];
    if ($score < $this->thresholds['medium']) return ['medium', 'Medium Risk', '#ff9800'];
    return ['high', 'High Risk', '#e53935'];
  }

  /** Starch % of DM thresholds (supplementary UI guidance). */
  protected function classifyStarch(float $pct): string {
    if ($pct <= 25.0) return 'optimal';
    if ($pct <= 35.0) return 'elevated';
    return 'high';
  }

  /** NDF % of DM thresholds (supplementary UI guidance). */
  protected function classifyNdf(float $pct): string {
    if ($pct >= 32.0) return 'optimal';
    if ($pct >= 25.0) return 'low';
    return 'critical';
  }

  /** Heat stress from temperature selection. */
  protected function classifyHeatStress(string $temp): string {
    return match ($temp) {
      'hot_and_humid'  => 'severe',
      'hot' => 'moderate',
      default => 'none',
    };
  }

  /** Buffer adequacy based on existing NaHCO3 + MgO. */
  protected function classifyBuffer(float $nahco3, float $mgo): string {
    $total_buffer_equivalent = $nahco3 + ($mgo * 1.5);
    if ($total_buffer_equivalent >= 150) return 'adequate';
    if ($total_buffer_equivalent > 0)   return 'partial';
    return 'none';
  }

  // ══════════════════════════════════════════════════════════════════════════
  // PRIVATE: DYNAMIC MESSAGE BUILDER
  // ══════════════════════════════════════════════════════════════════════════

  /**
   * Builds an ordered array of contextual message blocks.
   *
   * Each block is an associative array:
   *   - type:    'success' | 'warning' | 'danger' | 'info'   (for CSS class)
   *   - icon:    emoji or SVG identifier string
   *   - title:   short bold heading (translated)
   *   - body:    1-2 sentence explanation (translated)
   *   - trigger: machine-name of the signal that triggered this block
   *
   * Blocks are ordered from most critical (risk level) down to supplementary
   * observations (buffer, forage length).
   *
   * @return array[]
   */
  protected function buildDynamicMessages(
    string $risk_level,
    string $risk_label,
    float  $score,
    float  $starch_pct,
    float  $ndf_pct,
    string $starch_status,
    string $ndf_status,
    string $heat_stress,
    bool   $symptoms,
    string $buffer_status,
    float  $recommended_dosage,
    string $forage_length
  ): array {

    $messages = [];

    // ── Block A: Overall risk level (0-5 sub-acidosis risk index) ────────
    $messages[] = match ($risk_level) {
      'low' => [
        'type'    => 'success',
        'icon'    => '✅',
        'title'   => (string) t('Your ration looks well balanced'),
        'body'    => (string) t('The calculated sub-acidosis risk index is @score out of 5 — within the safe range (below 1.53). Your current ration presents a low risk of ruminal acidosis.', ['@score' => round($score, 2)]),
        'trigger' => 'risk_level',
      ],
      'medium' => [
        'type'    => 'warning',
        'icon'    => '⚠️',
        'title'   => (string) t('Moderate acidosis risk detected'),
        'body'    => (string) t('The sub-acidosis risk index is @score out of 5, placing your ration in the medium-risk zone (1.53–3.39). Rumen buffering capacity may be compromised — monitoring and adjustment are advisable.', ['@score' => round($score, 2)]),
        'trigger' => 'risk_level',
      ],
      default => [
        'type'    => 'danger',
        'icon'    => '🚨',
        'title'   => (string) t('High acidosis risk — immediate action recommended'),
        'body'    => (string) t('The sub-acidosis risk index is @score out of 5, which exceeds the safe threshold of 3.39. Your cow\'s rumen buffer is likely overwhelmed. Ration reformulation and Bicar®Z supplementation are strongly recommended.', ['@score' => round($score, 2)]),
        'trigger' => 'risk_level',
      ],
    };

    // ── Block B: Starch load ─────────────────────────────────────────────
    if ($starch_status === 'elevated') {
      $messages[] = [
        'type'    => 'warning',
        'icon'    => '🌽',
        'title'   => (string) t('Starch content is elevated (@pct% of DM)', ['@pct' => round($starch_pct, 1)]),
        'body'    => (string) t('Starch above 25% of dry matter increases rumen acid production. Consider replacing part of the high-starch concentrate with lower-starch alternatives or adding more structural fibre.'),
        'trigger' => 'starch',
      ];
    } elseif ($starch_status === 'high') {
      $messages[] = [
        'type'    => 'danger',
        'icon'    => '🌽',
        'title'   => (string) t('Starch load is critically high (@pct% of DM)', ['@pct' => round($starch_pct, 1)]),
        'body'    => (string) t('At @pct% starch in dry matter, rapid rumen fermentation is very likely. Reducing high-starch ingredients (corn, barley flakes) and increasing hay or straw is strongly advised. A Bicar®Z supplementation of @dosage g/cow/day is recommended.', ['@pct' => round($starch_pct, 1), '@dosage' => $recommended_dosage]),
        'trigger' => 'starch',
      ];
    } else {
      $messages[] = [
        'type'    => 'success',
        'icon'    => '🌽',
        'title'   => (string) t('Starch content is within the optimal range (@pct% of DM)', ['@pct' => round($starch_pct, 1)]),
        'body'    => (string) t('Starch below 25% of dry matter keeps fermentation rate at a manageable level for rumen buffering. No concentrate adjustment is needed for this parameter.'),
        'trigger' => 'starch',
      ];
    }

    // ── Block C: NDF / Fibre ─────────────────────────────────────────────
    if ($ndf_status === 'critical') {
      $messages[] = [
        'type'    => 'danger',
        'icon'    => '🌿',
        'title'   => (string) t('Fibre (NDF) is critically low (@pct% of DM)', ['@pct' => round($ndf_pct, 1)]),
        'body'    => (string) t('NDF below 25% severely limits rumen mat formation and chewing activity, reducing natural salivary buffering. Increase structural forage (long hay, straw) immediately.'),
        'trigger' => 'ndf',
      ];
    } elseif ($ndf_status === 'low') {
      $messages[] = [
        'type'    => 'warning',
        'icon'    => '🌿',
        'title'   => (string) t('Fibre (NDF) is below the recommended level (@pct% of DM)', ['@pct' => round($ndf_pct, 1)]),
        'body'    => (string) t('NDF between 25–32% is lower than the recommended 32% minimum. Adding alfalfa, hay or straw will improve rumen mat quality and increase saliva production.'),
        'trigger' => 'ndf',
      ];
    } else {
      $messages[] = [
        'type'    => 'success',
        'icon'    => '🌿',
        'title'   => (string) t('Fibre (NDF) level is adequate (@pct% of DM)', ['@pct' => round($ndf_pct, 1)]),
        'body'    => (string) t('NDF at or above 32% of dry matter supports a healthy rumen mat and adequate saliva production. Your forage inclusion is appropriate.'),
        'trigger' => 'ndf',
      ];
    }

    // ── Block D: Heat stress ─────────────────────────────────────────────
    if ($heat_stress === 'severe') {
      $messages[] = [
        'type'    => 'danger',
        'icon'    => '🌡️',
        'title'   => (string) t('Severe heat stress conditions (>28°C)'),
        'body'    => (string) t('High ambient temperature dramatically reduces dry matter intake and increases respiratory rate, lowering rumen pH. This is factored into the predicted average rumen pH used for your risk index.'),
        'trigger' => 'heat_stress',
      ];
    } elseif ($heat_stress === 'moderate') {
      $messages[] = [
        'type'    => 'warning',
        'icon'    => '🌡️',
        'title'   => (string) t('Moderate heat stress conditions (25–28°C)'),
        'body'    => (string) t('Warm conditions can reduce feed intake and rumination time, increasing acidosis risk. Ensure adequate shade and fresh water; this has been factored into your risk index.'),
        'trigger' => 'heat_stress',
      ];
    }

    // ── Block E: Acidosis symptoms ───────────────────────────────────────
    if ($symptoms) {
      $messages[] = [
        'type'    => 'danger',
        'icon'    => '🐄',
        'title'   => (string) t('Clinical acidosis symptoms have been observed'),
        'body'    => (string) t('Observed symptoms such as laminitis, abnormal stool pH, or dull coat indicate that sub-acute or acute ruminal acidosis may already be occurring. This raises the calculated risk index by 20%. Consult a veterinarian promptly and consider immediate Bicar®Z supplementation.'),
        'trigger' => 'symptoms',
      ];
    } else {
      $messages[] = [
        'type'    => 'success',
        'icon'    => '🐄',
        'title'   => (string) t('No clinical acidosis symptoms reported'),
        'body'    => (string) t('No visible symptoms have been observed. Continue to monitor your herd for early signs such as changes in stool consistency, reduced rumination, or lameness.'),
        'trigger' => 'symptoms',
      ];
    }

    // ── Block F: Forage cutting length ───────────────────────────────────
    if ($forage_length === 'short') {
      $messages[] = [
        'type'    => 'warning',
        'icon'    => '✂️',
        'title'   => (string) t('Short forage cutting length (<3 cm) detected'),
        'body'    => (string) t('Fine particle size reduces the physical scratch factor of the ration, limiting rumination and salivary bicarbonate production. Consider longer cutting lengths or adding chopped straw to improve rumen mat quality.'),
        'trigger' => 'forage_length',
      ];
    } elseif ($forage_length === 'medium') {
      $messages[] = [
        'type'    => 'info',
        'icon'    => '✂️',
        'title'   => (string) t('Forage cutting length is moderate (3–8 cm)'),
        'body'    => (string) t('Medium particle length provides some physical buffering benefit. Longer cut lengths (>8 cm) would further stimulate rumination and saliva flow.'),
        'trigger' => 'forage_length',
      ];
    } elseif ($forage_length === 'long') {
      $messages[] = [
        'type'    => 'success',
        'icon'    => '✂️',
        'title'   => (string) t('Forage cutting length is optimal (>8 cm)'),
        'body'    => (string) t('Long particle size maximises rumen mat formation, chewing activity and salivary buffering. This is the ideal cutting length for acidosis prevention.'),
        'trigger' => 'forage_length',
      ];
    }

    // ── Block G: Buffer supplementation ─────────────────────────────────
    if ($buffer_status === 'none' && $risk_level !== 'low') {
      $messages[] = [
        'type'    => 'warning',
        'icon'    => '💊',
        'title'   => (string) t('No buffer supplementation currently in ration'),
        'body'    => (string) t('Given the elevated risk index, adding @dosage g/cow/day of Bicar®Z (sodium bicarbonate) will help stabilise rumen pH and protect milk fat production.', ['@dosage' => $recommended_dosage]),
        'trigger' => 'buffer',
      ];
    } elseif ($buffer_status === 'partial') {
      $messages[] = [
        'type'    => 'info',
        'icon'    => '💊',
        'title'   => (string) t('Partial buffer supplementation detected'),
        'body'    => (string) t('Some buffering agents are already in the ration. Based on the current risk level, an additional @dosage g/cow/day of Bicar®Z is recommended to reach the optimal buffering capacity.', ['@dosage' => $recommended_dosage]),
        'trigger' => 'buffer',
      ];
    } elseif ($buffer_status === 'adequate') {
      $messages[] = [
        'type'    => 'success',
        'icon'    => '💊',
        'title'   => (string) t('Buffer supplementation is adequate'),
        'body'    => (string) t('The current level of sodium bicarbonate and magnesium oxide in the ration provides sufficient rumen buffering capacity for the observed conditions.'),
        'trigger' => 'buffer',
      ];
    }

    return $messages;
  }

  protected function getCowMessage(string $risk_level): string {
    return match ($risk_level) {
      'low'  => (string) t("I'm in great shape and ready to give the best of myself! Your cow's acid-base balance is ideal and its yield is optimal."),
      'high' => (string) t("Ouch, I certainly suffer from Ruminal Acidosis. Please give me some Bicar®Z! Your cow's acido-basic balance is bad. Increase the dose of Bicar®Z!"),
      default => (string) t("I'm not feeling good. Please increase my dose of Bicar®Z! Your cow's acido-balance isn't optimal."),
    };
  }
}
