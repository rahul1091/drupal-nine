<?php

namespace Drupal\solvay_acidosis_calculator\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Admin settings form for the AI-personalized dosage/ration recommendation
 * feature on the Acidosis Calculator results page.
 */
class AiSettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames(): array {
    return ['solvay_acidosis_calculator.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string {
    return 'solvay_acidosis_calculator_ai_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $config = $this->config('solvay_acidosis_calculator.settings');

    $form['ai_enabled'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable AI-personalized recommendations'),
      '#description' => $this->t('When disabled, the results page shows only the rule-based score and dosage — the AI panel is not shown and no external API calls are made.'),
      '#default_value' => $config->get('ai_enabled') ?? FALSE,
    ];

    $form['api'] = [
      '#type' => 'details',
      '#title' => $this->t('API configuration'),
      '#open' => TRUE,
      '#states' => [
        'visible' => [
          ':input[name="ai_enabled"]' => ['checked' => TRUE],
        ],
      ],
    ];

    $form['api']['api_endpoint'] = [
      '#type' => 'url',
      '#title' => $this->t('API endpoint'),
      '#default_value' => $config->get('api_endpoint') ?? 'https://api.anthropic.com/v1/messages',
      '#required' => FALSE,
    ];

    $form['api']['model'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Model'),
      '#default_value' => $config->get('model') ?? 'claude-sonnet-4-6',
      '#description' => $this->t('The model identifier to send in the API request.'),
    ];

    // API key: prefer the Key module (drupal/key) so the secret itself
    // lives in an environment variable / secrets manager rather than in
    // exported config. This field stores the KEY NAME, not the secret.
    if (\Drupal::moduleHandler()->moduleExists('key')) {
      $form['api']['api_key'] = [
        '#type' => 'key_select',
        '#title' => $this->t('API key'),
        '#default_value' => $config->get('api_key'),
        '#description' => $this->t('Select the Key entity storing your AI provider API key.'),
        '#empty_option' => $this->t('- Select -'),
      ];
    }
    else {
      $form['api']['api_key'] = [
        '#type' => 'textfield',
        '#title' => $this->t('API key'),
        '#default_value' => $config->get('api_key'),
        '#description' => $this->t('<strong>Warning:</strong> the Key module (drupal/key) is not installed. Storing the raw API key here means it will be exported in plain text with your site config. Installing and using the Key module is strongly recommended for production.'),
      ];
    }

    $form['api']['timeout'] = [
      '#type' => 'number',
      '#title' => $this->t('Request timeout (seconds)'),
      '#default_value' => $config->get('timeout') ?? 8,
      '#min' => 1,
      '#max' => 30,
    ];

    $form['api']['daily_call_budget'] = [
      '#type' => 'number',
      '#title' => $this->t('Daily API call budget'),
      '#default_value' => $config->get('daily_call_budget') ?? 500,
      '#min' => 0,
      '#description' => $this->t('Safety cap on AI calls per day, site-wide. Set to 0 for no limit. Once the budget is reached for the day, the AI panel is skipped (rule-based results still show normally) until the next day.'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void {
    parent::validateForm($form, $form_state);

    if ($form_state->getValue('ai_enabled')) {
      if (!$form_state->getValue('api_endpoint')) {
        $form_state->setErrorByName('api_endpoint', $this->t('API endpoint is required when AI recommendations are enabled.'));
      }
      if (!$form_state->getValue('api_key')) {
        $form_state->setErrorByName('api_key', $this->t('An API key must be configured when AI recommendations are enabled.'));
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $this->config('solvay_acidosis_calculator.settings')
      ->set('ai_enabled', (bool) $form_state->getValue('ai_enabled'))
      ->set('api_endpoint', $form_state->getValue('api_endpoint'))
      ->set('model', $form_state->getValue('model'))
      ->set('api_key', $form_state->getValue('api_key'))
      ->set('timeout', (int) $form_state->getValue('timeout'))
      ->set('daily_call_budget', (int) $form_state->getValue('daily_call_budget'))
      ->save();

    parent::submitForm($form, $form_state);
  }

}
