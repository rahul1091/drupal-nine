# Aurelia

A fully independent, custom Drupal 11 theme (**not** a sub-theme — `base theme: false`
in `aurelia.info.yml`). Aurelia owns its complete page markup, styling, and behavior
and does not inherit templates, CSS, or JS from Olivero or any other base theme.

## What this theme does
- **Independent page structure:** `templates/layout/page.html.twig` defines the
  entire page shell (header, branding, main navigation, highlighted region,
  breadcrumb, content, footer) from scratch.
- **Header & main navigation:** custom sticky header with logo/site name/slogan,
  a responsive main menu (`templates/navigation/menu--main.html.twig`) that
  becomes a dropdown nav on desktop and an off-canvas panel on mobile
  (`css/navigation.css`, `js/navigation.js`).
- **Breadcrumb:** custom `templates/misc/breadcrumb.html.twig` with schema.org
  `BreadcrumbList` markup (`css/breadcrumb.css`).
- **Base reset:** `css/base.css` provides the box-sizing reset, image defaults,
  and the `.visually-hidden` / `.focusable` accessibility utility classes used
  by the skip link, block titles, etc. — this replaces what used to be
  inherited from Olivero.
- **Max page width:** 1920px via the `--max-width` custom property.
- **Typography:** Caveat Brush / Montserrat / Nunito Sans, loaded via the
  `aurelia/fonts` library.
- **Responsive breakpoints:** mobile-first media queries at **375px, 425px,
  768px, 1024px and 1440px**, plus a matching `aurelia.breakpoints.yml`.

## Why independent rather than a sub-theme
Being independent means Aurelia's markup, class names, and CSS are entirely
under this theme's control — nothing changes underneath it when Drupal core
updates Olivero. The trade-off: Aurelia is responsible for its own
foundational styling (resets, accessibility utilities, base page structure)
rather than inheriting it, and other Drupal-rendered elements not explicitly
themed here (forms, tables, views, comments, etc.) will render with browser
default styling until templates/CSS are added for them.

## Installation
1. Copy the `aurelia` folder to `web/themes/custom/aurelia`.
2. Enable it: `drush theme:enable aurelia` (or via **Appearance** in the admin UI).
3. Set it as default: `drush config-set system.theme default aurelia` (or via **Appearance**).
4. Clear cache: `drush cr`.

## File structure
```
aurelia/
├── aurelia.info.yml
├── aurelia.libraries.yml
├── aurelia.breakpoints.yml
├── aurelia.theme
├── logo.svg
├── css/
│   ├── base.css               # Reset + accessibility utilities
│   ├── style.css               # Typography, layout tokens, global rules
│   ├── header.css
│   ├── navigation.css
│   ├── breadcrumb.css
│   ├── footer.css
│   ├── language-toggle.css
│   ├── page-banner.css
│   ├── image-content.css
│   ├── image-content-cta.css
│   └── image-slider.css
├── js/
│   ├── navigation.js
│   ├── language-toggle.js
│   └── image-slider.js
└── templates/
    ├── layout/
    │   └── page.html.twig
    ├── navigation/
    │   ├── menu--main.html.twig
    │   └── links--language-block.html.twig
    ├── misc/
    │   └── breadcrumb.html.twig
    ├── block/
    │   ├── block--block-content.html.twig
    │   └── block--language-block.html.twig
    └── paragraph/
        ├── paragraph--page-banner.html.twig
        ├── paragraph--image-content.html.twig
        ├── paragraph--image-content-cta.html.twig
        ├── paragraph--image-slider.html.twig
        └── paragraph--image-slide.html.twig
```

## Notes
- **Font loading via Google Fonts CDN:** simplest setup, but it's an external
  request and a minor GDPR consideration in the EU. For self-hosted fonts
  instead: download the `.woff2` files, put them in a `fonts/` folder, replace
  the `fonts` library in `aurelia.libraries.yml` with `@font-face` rules in
  `css/base.css`, and remove the Google Fonts CDN entries.
- Forms, tables, views output, and other Drupal-rendered markup not covered by
  the templates above will use plain browser defaults until you add theming
  for them — expected for an independent theme with no base theme to fall back on.
