(function (Drupal, once) {
  Drupal.behaviors.aureliaMainNavToggle = {
    attach: function (context) {
      once('aureliaMainNavToggle', '.js-nav-toggle', context).forEach(function (toggle) {
        const nav = document.querySelector('.js-main-nav');
        const backdrop = document.querySelector('.js-nav-backdrop');

        if (!nav) {
          return;
        }

        function closeNav() {
          nav.classList.remove('is-open');
          toggle.setAttribute('aria-expanded', 'false');
          if (backdrop) {
            backdrop.classList.remove('is-visible');
          }
        }

        function openNav() {
          nav.classList.add('is-open');
          toggle.setAttribute('aria-expanded', 'true');
          if (backdrop) {
            backdrop.classList.add('is-visible');
          }
        }

        toggle.addEventListener('click', function () {
          if (nav.classList.contains('is-open')) {
            closeNav();
          } else {
            openNav();
          }
        });

        if (backdrop) {
          backdrop.addEventListener('click', closeNav);
        }

        document.addEventListener('keydown', function (event) {
          if (event.key === 'Escape' && nav.classList.contains('is-open')) {
            closeNav();
            toggle.focus();
          }
        });

        document.addEventListener('click', function (event) {
          if (
            nav.classList.contains('is-open')
            && !nav.contains(event.target)
            && !toggle.contains(event.target)
            && (!backdrop || !backdrop.contains(event.target))
          ) {
            closeNav();
          }
        });
      });
    }
  };

  Drupal.behaviors.aureliaSubmenuToggle = {
    attach: function (context) {
      once('aureliaSubmenuToggle', '.js-submenu-toggle', context).forEach(function (button) {
        const item = button.closest('.main-nav__item--has-children');

        if (!item) {
          return;
        }

        button.addEventListener('click', function (event) {
          event.preventDefault();

          const isOpen = item.classList.toggle('is-submenu-open');

          button.setAttribute('aria-expanded', isOpen ? 'true' : 'false');

          // Close sibling submenus so only one is open at a time.
          const siblings = Array.from(
            item.parentElement.children
          ).filter(function (sibling) {
            return sibling !== item;
          });

          siblings.forEach(function (sibling) {
            sibling.classList.remove('is-submenu-open');
            const siblingButton = sibling.querySelector('.js-submenu-toggle');
            if (siblingButton) {
              siblingButton.setAttribute('aria-expanded', 'false');
            }
          });
        });
      });

      document.addEventListener('click', function (event) {
        document.querySelectorAll('.main-nav__item--has-children.is-submenu-open').forEach(function (openItem) {
          if (!openItem.contains(event.target)) {
            openItem.classList.remove('is-submenu-open');
            const btn = openItem.querySelector('.js-submenu-toggle');
            if (btn) {
              btn.setAttribute('aria-expanded', 'false');
            }
          }
        });
      });
    }
  };
})(Drupal, once);
