(function (Drupal, once) {
  Drupal.behaviors.languageSwitcherDropdown = {
    attach: function (context) {
      once('languageSwitcherDropdown', '.js-language-dropdown', context).forEach(function (dropdown) {
        const toggle = dropdown.querySelector('.js-language-dropdown-toggle');
        const menu = dropdown.querySelector('.js-language-dropdown-menu');
        const selectedLanguage = dropdown.querySelector('.js-selected-language');

        if (!toggle || !menu || !selectedLanguage) {
          return;
        }

        /**
         * Set active language in dropdown button.
         * Default will remain EN if no active language is found.
         */
        const activeLink =
          menu.querySelector('.language-dropdown-link.is-active') ||
          menu.querySelector('.language-dropdown-link[aria-current="true"]') ||
          menu.querySelector('a.is-active') ||
          menu.querySelector('a[aria-current="true"]');

        if (activeLink) {
          const activeLanguageCode =
            activeLink.getAttribute('data-language-code') ||
            activeLink.getAttribute('hreflang') ||
            activeLink.textContent.trim();

          if (activeLanguageCode) {
            selectedLanguage.textContent = activeLanguageCode.toUpperCase();
          }
        }

        toggle.addEventListener('click', function (event) {
          event.preventDefault();
          event.stopPropagation();

          const isOpen = dropdown.classList.toggle('is-open');

          toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        document.addEventListener('click', function (event) {
          if (!dropdown.contains(event.target)) {
            dropdown.classList.remove('is-open');
            toggle.setAttribute('aria-expanded', 'false');
          }
        });

        document.addEventListener('keydown', function (event) {
          if (event.key === 'Escape') {
            dropdown.classList.remove('is-open');
            toggle.setAttribute('aria-expanded', 'false');
          }
        });
      });
    }
  };
})(Drupal, once);