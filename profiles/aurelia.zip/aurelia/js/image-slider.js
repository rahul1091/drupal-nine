(function (Drupal, once) {
  Drupal.behaviors.aureliaImageSlider = {
    attach: function (context) {
      once('aureliaImageSlider', '.js-image-slider', context).forEach(function (el) {
        if (typeof Swiper === 'undefined') {
          return;
        }

        const swiperEl = el.querySelector('.image-slider__swiper');

        if (!swiperEl) {
          return;
        }

        const autoplay = el.dataset.autoplay === 'true';
        const autoplaySpeed = parseInt(el.dataset.autoplaySpeed, 10) || 5000;
        const showArrows = el.dataset.navArrows === 'true';
        const showDots = el.dataset.paginationDots === 'true';

        const options = {
          loop: true,
          spaceBetween: 20,
          centeredSlides: true,
          slideToClickedSlide: true,
          a11y: {
            enabled: true,
          },
          keyboard: {
            enabled: true,
          },
          breakpoints: {
            // Below 1024px: single, full-width slide.
            0: {
              slidesPerView: 1,
              centeredSlides: false,
              spaceBetween: 0,
            },
            // 1024px and above: 3 slides, center one emphasized.
            1024: {
              slidesPerView: 3,
              centeredSlides: true,
              spaceBetween: 24,
            },
          },
        };

        if (autoplay) {
          options.autoplay = {
            delay: autoplaySpeed,
            disableOnInteraction: false,
          };
        }

        if (showDots) {
          options.pagination = {
            el: el.querySelector('.image-slider__pagination'),
            clickable: true,
          };
        }

        if (showArrows) {
          options.navigation = {
            nextEl: el.querySelector('.image-slider__nav--next'),
            prevEl: el.querySelector('.image-slider__nav--prev'),
          };
        }

        // eslint-disable-next-line no-new
        new Swiper(swiperEl, options);
      });
    }
  };
})(Drupal, once);
