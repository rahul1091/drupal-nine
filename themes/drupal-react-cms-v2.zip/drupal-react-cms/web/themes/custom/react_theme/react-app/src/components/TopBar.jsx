import React from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';

export default function TopBar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/project-trackers');
  };

  const navLinkClass = ({ isActive }) =>
    `btn btn-ghost btn-sm${isActive ? ' nav-active' : ''}`;

  return (
    <header className="app-topbar">
      <Link to="/project-trackers" className="app-topbar__brand">
        🗂 Drupal React CMS
      </Link>

      <nav className="app-topbar__nav">
        <NavLink to="/project-trackers" className={navLinkClass}>Trackers</NavLink>
        {user && <NavLink to="/articles" className={navLinkClass}>Articles</NavLink>}

        {user ? (
          <>
            <span className="app-topbar__user">{user.name}</span>
            <button className="btn btn-ghost btn-sm" onClick={handleLogout}>Log out</button>
          </>
        ) : (
          <Link to="/login" className="btn btn-primary btn-sm">Log in</Link>
        )}
      </nav>
    </header>
  );
}
