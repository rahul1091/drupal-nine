/**
 * ProjectTrackerForm.jsx
 *
 * Create / edit form for a project_tracker node.
 * Fields: title, description, status, severity, due_date
 *
 * Props:
 *   initialValues  – pre-fill when editing; defaults to empty
 *   onSubmit(data) – async callback with form payload
 *   onCancel()     – cancel handler
 *   isLoading      – shows spinner on submit button
 */
import React, { useState } from 'react';
import { STATUS_OPTIONS, SEVERITY_OPTIONS } from '@/api/projectTrackers';

const EMPTY = {
  title:       '',
  description: '',
  status:      'open',
  severity:    'medium',
  due_date:    '',
};

export default function ProjectTrackerForm({ initialValues = EMPTY, onSubmit, onCancel, isLoading }) {
  const [values, setValues] = useState({ ...EMPTY, ...initialValues });
  const [errors, setErrors] = useState({});

  const set = (field) => (e) => {
    setValues((v) => ({ ...v, [field]: e.target.value }));
    if (errors[field]) setErrors((e) => ({ ...e, [field]: '' }));
  };

  const validate = () => {
    const next = {};
    if (!values.title.trim()) next.title = 'Title is required.';
    if (values.title.length > 255) next.title = 'Title must be under 255 characters.';
    if (values.due_date) {
      const d = new Date(values.due_date);
      if (isNaN(d.getTime())) next.due_date = 'Enter a valid date.';
    }
    return next;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    await onSubmit({
      ...values,
      due_date: values.due_date || null,
    });
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      {/* Title */}
      <div className="form-group">
        <label className="form-label" htmlFor="pt-title">
          Title <span style={{ color: 'var(--c-danger)' }}>*</span>
        </label>
        <input
          id="pt-title"
          type="text"
          className="form-input"
          value={values.title}
          onChange={set('title')}
          placeholder="Project name or issue title"
          maxLength={255}
        />
        {errors.title && <span className="form-error">{errors.title}</span>}
      </div>

      {/* Description */}
      <div className="form-group">
        <label className="form-label" htmlFor="pt-desc">Description</label>
        <textarea
          id="pt-desc"
          className="form-textarea"
          value={values.description}
          onChange={set('description')}
          placeholder="Describe the project, issue, or task…"
          rows={5}
        />
      </div>

      {/* Status + Severity side by side */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
        <div className="form-group">
          <label className="form-label" htmlFor="pt-status">Status</label>
          <select
            id="pt-status"
            className="form-select"
            value={values.status}
            onChange={set('status')}
          >
            {STATUS_OPTIONS.map(({ value, label }) => (
              <option key={value} value={value}>{label}</option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="pt-severity">Severity</label>
          <select
            id="pt-severity"
            className="form-select"
            value={values.severity}
            onChange={set('severity')}
          >
            {SEVERITY_OPTIONS.map(({ value, label }) => (
              <option key={value} value={value}>{label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Due Date */}
      <div className="form-group">
        <label className="form-label" htmlFor="pt-due">Due Date</label>
        <input
          id="pt-due"
          type="date"
          className="form-input"
          value={values.due_date || ''}
          onChange={set('due_date')}
          style={{ maxWidth: 220 }}
        />
        {errors.due_date && <span className="form-error">{errors.due_date}</span>}
      </div>

      <div className="modal__footer">
        <button type="button" className="btn btn-ghost" onClick={onCancel} disabled={isLoading}>
          Cancel
        </button>
        <button type="submit" className="btn btn-primary" disabled={isLoading}>
          {isLoading ? <span className="spinner" /> : null}
          {initialValues.title ? 'Save changes' : 'Create tracker'}
        </button>
      </div>
    </form>
  );
}
