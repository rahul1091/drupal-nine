import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');

  return {
    plugins: [react()],

    // Dev server – proxies /api/* to local Drupal
    server: {
      port: 5173,
      proxy: {
        '/api': {
          target: env.VITE_DRUPAL_BASE_URL || 'http://localhost:8888',
          changeOrigin: true,
          secure: false,
        },
        '/session': {
          target: env.VITE_DRUPAL_BASE_URL || 'http://localhost:8888',
          changeOrigin: true,
          secure: false,
        },
        '/user': {
          target: env.VITE_DRUPAL_BASE_URL || 'http://localhost:8888',
          changeOrigin: true,
          secure: false,
        },
      },
    },

    // Build → output to the theme's js/ folder so Drupal picks it up
    build: {
      outDir: path.resolve(__dirname, '../js'),
      emptyOutDir: false,
      rollupOptions: {
        input: path.resolve(__dirname, 'src/main.jsx'),
        output: {
          // Single file: js/app.js  (matched in react_theme.libraries.yml)
          entryFileNames: 'app.js',
          chunkFileNames: 'app.js',
          assetFileNames: 'app.[ext]',
          // Inline everything into one bundle; Drupal handles caching.
          manualChunks: undefined,
          format: 'iife',
          name: 'ReactApp',
        },
      },
      sourcemap: mode === 'development',
    },

    resolve: {
      alias: {
        '@': path.resolve(__dirname, 'src'),
      },
    },
  };
});
