/**
 * hooks/useAuth.js
 *
 * Manages authentication state.
 * In the Drupal-embedded context the user is already authenticated via Drupal's
 * session cookie – we just read their info from drupalSettings.
 * In standalone dev mode we support interactive login.
 */
import { useState, useEffect, createContext, useContext } from 'react';
import { drupalLogin, drupalLogout } from '@/api/client';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser]       = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // If embedded in Drupal, bootstrap from drupalSettings
    const ds = window.drupalSettings?.reactApp?.currentUser;
    if (ds && !ds.isAnonymous) {
      setUser({
        id:       ds.id,
        name:     ds.name,
        roles:    ds.roles,
        isAdmin:  ds.roles?.includes('administrator'),
      });
    }
    setLoading(false);
  }, []);

  const login = async (name, pass) => {
    const drupalUser = await drupalLogin(name, pass);
    setUser({
      id:      drupalUser.uid,
      name:    drupalUser.name,
      roles:   [],
      isAdmin: false,
    });
  };

  const logout = async () => {
    const token = sessionStorage.getItem('csrf_token');
    await drupalLogout(token);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
