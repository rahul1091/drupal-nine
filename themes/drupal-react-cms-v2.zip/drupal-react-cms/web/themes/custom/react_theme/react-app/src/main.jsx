import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import './styles/global.css';

/**
 * Mount point: <div id="react-root"> injected by page.html.twig.
 *
 * drupalSettings is injected server-side by react_theme.theme and contains:
 *   window.drupalSettings.reactApp.baseUrl
 *   window.drupalSettings.reactApp.csrfToken
 *   window.drupalSettings.reactApp.currentUser
 */
const container = document.getElementById('react-root');

if (container) {
  ReactDOM.createRoot(container).render(
    <React.StrictMode>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </React.StrictMode>
  );
}
