/**
 * api/articles.js
 *
 * Wrappers for the ArticlesResource REST endpoints.
 * All calls go through client.js which automatically appends ?_format=json.
 *
 * Endpoint base: /api/articles
 */
import api from './client';

export async function getArticles(params = {}) {
  const { data } = await api.get('/articles', { params });
  return data; // { data: Article[], meta: PaginationMeta }
}

export async function getArticle(id) {
  const { data } = await api.get(`/articles/${id}`);
  return data.data;
}

export async function createArticle(payload) {
  const { data } = await api.post('/articles', payload);
  return data;
}

export async function updateArticle(id, payload) {
  const { data } = await api.patch(`/articles/${id}`, payload);
  return data;
}

export async function deleteArticle(id) {
  await api.delete(`/articles/${id}`);
}
