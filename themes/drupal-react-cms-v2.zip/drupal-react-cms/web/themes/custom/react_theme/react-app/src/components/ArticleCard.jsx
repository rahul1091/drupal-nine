import React from 'react';
import { Link } from 'react-router-dom';

export default function ArticleCard({ article, onEdit, onDelete }) {
  const date = article.createdAt
    ? new Date(article.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    : '—';

  return (
    <div className="article-card">
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '.6rem', flexWrap: 'wrap' }}>
          <Link to={`/articles/${article.id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
            <h3 className="article-card__title">{article.title}</h3>
          </Link>
          <span className={`badge ${article.status ? 'badge-published' : 'badge-draft'}`}>
            {article.status ? 'Published' : 'Draft'}
          </span>
        </div>
        {article.summary && (
          <p style={{ marginTop: '.25rem', fontSize: '.875rem', color: 'var(--c-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 560 }}>
            {article.summary}
          </p>
        )}
        <div className="article-card__meta">
          <span className="article-card__author">By {article.author}</span>
          <span className="article-card__date">{date}</span>
          <span className="article-card__date">ID #{article.id}</span>
        </div>
      </div>
      <div className="article-card__actions">
        <button className="btn btn-ghost btn-sm" onClick={() => onEdit(article)}>Edit</button>
        <button className="btn btn-danger btn-sm" onClick={() => onDelete(article)}>Delete</button>
      </div>
    </div>
  );
}
