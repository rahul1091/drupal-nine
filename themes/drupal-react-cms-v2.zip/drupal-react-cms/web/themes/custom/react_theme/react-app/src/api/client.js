/**
 * api/client.js
 *
 * Axios instance for Drupal REST Resource endpoints.
 *
 * Key behaviours:
 *   • Automatically appends ?_format=json (required by Drupal REST)
 *   • Attaches X-CSRF-Token on mutating requests
 *   • Sends session cookies (withCredentials: true) for cookie-based auth
 *   • Reads runtime config from window.drupalSettings injected by react_theme.theme
 */
import axios from 'axios';

function getBaseUrl() {
  if (typeof window !== 'undefined' && window.drupalSettings?.reactApp?.baseUrl) {
    return window.drupalSettings.reactApp.baseUrl;
  }
  return import.meta.env.VITE_DRUPAL_BASE_URL || '';
}

const api = axios.create({
  baseURL: `${getBaseUrl()}${import.meta.env.VITE_API_PREFIX || '/api'}`,
  headers: { 'Content-Type': 'application/json' },
  withCredentials: true,
  // Drupal REST resources require _format=json on every request
  params: { _format: 'json' },
});

/** Attach CSRF token to every mutating request */
api.interceptors.request.use((config) => {
  const method = config.method?.toUpperCase();
  if (['POST', 'PATCH', 'PUT', 'DELETE'].includes(method)) {
    const drupalToken = window.drupalSettings?.reactApp?.csrfToken;
    const localToken  = sessionStorage.getItem('csrf_token');
    const token = drupalToken || localToken;
    if (token) config.headers['X-CSRF-Token'] = token;
  }
  return config;
});

/** Unwrap Drupal REST error shapes into plain Error objects */
api.interceptors.response.use(
  (res) => res,
  (err) => {
    const body = err.response?.data;
    const message =
      (typeof body === 'string' ? body : null) ||
      body?.message ||
      body?.error ||
      err.message ||
      'An unexpected error occurred.';
    return Promise.reject(new Error(message));
  }
);

export default api;

// ---------------------------------------------------------------------------
// Auth helpers (session-based)
// ---------------------------------------------------------------------------

export async function drupalLogin(name, pass) {
  const base = getBaseUrl();
  const resp = await fetch(`${base}/user/login?_format=json`, {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, pass }),
  });
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err.message || 'Login failed. Check your credentials.');
  }
  const data = await resp.json();
  sessionStorage.setItem('csrf_token', data.csrf_token || '');
  return data.current_user;
}

export async function drupalLogout(token) {
  const base = getBaseUrl();
  await fetch(`${base}/user/logout?_format=json&token=${encodeURIComponent(token || '')}`, {
    method: 'POST',
    credentials: 'include',
  });
  sessionStorage.removeItem('csrf_token');
}
