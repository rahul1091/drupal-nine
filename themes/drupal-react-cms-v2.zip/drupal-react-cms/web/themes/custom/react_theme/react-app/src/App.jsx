import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth }  from '@/hooks/useAuth';
import TopBar                     from '@/components/TopBar';
import LoginPage                  from '@/pages/LoginPage';
import ArticlesPage               from '@/pages/ArticlesPage';
import ArticleDetailPage          from '@/pages/ArticleDetailPage';
import ProjectTrackersPage        from '@/pages/ProjectTrackersPage';
import ProjectTrackerDetailPage   from '@/pages/ProjectTrackerDetailPage';

/** Redirect unauthenticated users away from auth-only pages */
function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="loading-center"><span className="spinner spinner-lg" /></div>;
  if (!user)   return <Navigate to="/login" replace />;
  return children;
}

function AppLayout() {
  return (
    <div className="app-layout">
      <TopBar />
      <main className="app-content">
        <Routes>
          {/* Default → project trackers (public) */}
          <Route path="/"        element={<Navigate to="/project-trackers" replace />} />
          <Route path="/login"   element={<LoginPage />} />

          {/* Project Trackers – public read, auth write (enforced in page + API) */}
          <Route path="/project-trackers"     element={<ProjectTrackersPage />} />
          <Route path="/project-trackers/:id" element={<ProjectTrackerDetailPage />} />

          {/* Articles – kept auth-protected at the page level */}
          <Route path="/articles"     element={<ProtectedRoute><ArticlesPage /></ProtectedRoute>} />
          <Route path="/articles/:id" element={<ProtectedRoute><ArticleDetailPage /></ProtectedRoute>} />

          <Route path="*" element={
            <div className="empty-state">
              <div className="empty-state__icon">🔍</div>
              <h2>Page not found</h2>
              <p>The URL you requested does not exist.</p>
            </div>
          } />
        </Routes>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppLayout />
    </AuthProvider>
  );
}
