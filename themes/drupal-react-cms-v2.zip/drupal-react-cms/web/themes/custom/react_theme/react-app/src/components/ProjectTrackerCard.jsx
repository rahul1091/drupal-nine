/**
 * ProjectTrackerCard.jsx
 *
 * Displays one project tracker in the list.
 * Edit/Delete actions are only shown to authenticated users.
 */
import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';

const STATUS_LABELS = {
  open:        'Open',
  in_progress: 'In Progress',
  on_hold:     'On Hold',
  completed:   'Completed',
  cancelled:   'Cancelled',
};

const SEVERITY_LABELS = {
  low:      'Low',
  medium:   'Medium',
  high:     'High',
  critical: 'Critical',
};

export default function ProjectTrackerCard({ tracker, onEdit, onDelete }) {
  const { user } = useAuth();

  const createdDate = tracker.createdAt
    ? new Date(tracker.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    : '—';

  const dueDate = tracker.due_date
    ? new Date(tracker.due_date + 'T00:00:00').toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    : null;

  const isOverdue = tracker.due_date && new Date(tracker.due_date) < new Date()
    && !['completed', 'cancelled'].includes(tracker.status);

  return (
    <div className="tracker-card">
      <div className="tracker-card__main">
        {/* Title row */}
        <div className="tracker-card__title-row">
          <Link to={`/project-trackers/${tracker.id}`} className="tracker-card__title">
            {tracker.title}
          </Link>
          <div className="tracker-card__badges">
            <span className={`badge badge-status badge-status--${tracker.status}`}>
              {STATUS_LABELS[tracker.status] || tracker.status}
            </span>
            <span className={`badge badge-severity badge-severity--${tracker.severity}`}>
              {SEVERITY_LABELS[tracker.severity] || tracker.severity}
            </span>
          </div>
        </div>

        {/* Description preview */}
        {tracker.description && (
          <p className="tracker-card__desc">
            {tracker.description.replace(/<[^>]+>/g, '').slice(0, 140)}
            {tracker.description.length > 140 ? '…' : ''}
          </p>
        )}

        {/* Meta row */}
        <div className="tracker-card__meta">
          <span>By {tracker.author}</span>
          <span>Created {createdDate}</span>
          {dueDate && (
            <span className={isOverdue ? 'tracker-card__due--overdue' : ''}>
              {isOverdue ? '⚠ Overdue · ' : 'Due '}
              {dueDate}
            </span>
          )}
          <span style={{ color: 'var(--c-muted)', fontSize: '.8rem' }}>#{tracker.id}</span>
        </div>
      </div>

      {/* Actions – only for authenticated users */}
      {user && (
        <div className="tracker-card__actions">
          <button className="btn btn-ghost btn-sm" onClick={() => onEdit(tracker)}>Edit</button>
          <button className="btn btn-danger btn-sm" onClick={() => onDelete(tracker)}>Delete</button>
        </div>
      )}
    </div>
  );
}
