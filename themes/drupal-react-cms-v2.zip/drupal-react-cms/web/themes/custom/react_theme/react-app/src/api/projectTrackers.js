/**
 * api/projectTrackers.js
 *
 * Wrappers for the ProjectTrackersResource REST endpoints.
 *
 * Endpoint base: /api/project-trackers  (all require ?_format=json, added by client)
 *
 * Field reference:
 *   title        string   required
 *   description  string   long text
 *   status       string   open | in_progress | on_hold | completed | cancelled
 *   severity     string   low | medium | high | critical
 *   due_date     string   YYYY-MM-DD  or null
 */
import api from './client';

export const STATUS_OPTIONS = [
  { value: 'open',        label: 'Open' },
  { value: 'in_progress', label: 'In Progress' },
  { value: 'on_hold',     label: 'On Hold' },
  { value: 'completed',   label: 'Completed' },
  { value: 'cancelled',   label: 'Cancelled' },
];

export const SEVERITY_OPTIONS = [
  { value: 'low',      label: 'Low' },
  { value: 'medium',   label: 'Medium' },
  { value: 'high',     label: 'High' },
  { value: 'critical', label: 'Critical' },
];

/**
 * GET /api/project-trackers
 * @param {{ page?, limit?, status?, severity? }} params
 */
export async function getProjectTrackers(params = {}) {
  const { data } = await api.get('/project-trackers', { params });
  return data; // { data: [], meta: {} }
}

/**
 * GET /api/project-trackers/:id
 */
export async function getProjectTracker(id) {
  const { data } = await api.get(`/project-trackers/${id}`);
  return data.data;
}

/**
 * POST /api/project-trackers  (auth required)
 */
export async function createProjectTracker(payload) {
  const { data } = await api.post('/project-trackers', payload);
  return data; // { data: tracker, message: string }
}

/**
 * PATCH /api/project-trackers/:id  (auth required)
 */
export async function updateProjectTracker(id, payload) {
  const { data } = await api.patch(`/project-trackers/${id}`, payload);
  return data;
}

/**
 * DELETE /api/project-trackers/:id  (auth required)
 * Returns undefined on 204.
 */
export async function deleteProjectTracker(id) {
  await api.delete(`/project-trackers/${id}`);
}
