/**
 * hooks/useProjectTrackers.js
 *
 * Manages project tracker list state: fetching, pagination, filters,
 * and optimistic removal.
 */
import { useState, useCallback } from 'react';
import { getProjectTrackers, deleteProjectTracker } from '@/api/projectTrackers';

export function useProjectTrackers(initialLimit = 10) {
  const [trackers, setTrackers] = useState([]);
  const [meta,     setMeta]     = useState({ total: 0, page: 0, pages: 0 });
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState(null);

  const fetchTrackers = useCallback(async (page = 0, filters = {}) => {
    setLoading(true);
    setError(null);
    try {
      const result = await getProjectTrackers({ page, limit: initialLimit, ...filters });
      setTrackers(result.data);
      setMeta(result.meta);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [initialLimit]);

  const removeTracker = useCallback(async (id) => {
    await deleteProjectTracker(id);
    setTrackers((prev) => prev.filter((t) => t.id !== id));
    setMeta((prev) => ({ ...prev, total: Math.max(0, prev.total - 1) }));
  }, []);

  return { trackers, meta, loading, error, fetchTrackers, removeTracker };
}
