import { useState, useCallback } from 'react';
import { getArticles, deleteArticle } from '@/api/articles';

export function useArticles(initialLimit = 10) {
  const [articles, setArticles] = useState([]);
  const [meta,     setMeta]     = useState({ total: 0, page: 0, pages: 0 });
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState(null);

  const fetchArticles = useCallback(async (page = 0, limit = initialLimit) => {
    setLoading(true);
    setError(null);
    try {
      const result = await getArticles({ page, limit });
      setArticles(result.data);
      setMeta(result.meta);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [initialLimit]);

  const removeArticle = useCallback(async (id) => {
    await deleteArticle(id);
    setArticles((prev) => prev.filter((a) => a.id !== id));
    setMeta((prev) => ({ ...prev, total: Math.max(0, prev.total - 1) }));
  }, []);

  return { articles, meta, loading, error, fetchArticles, removeArticle };
}
