import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { getArticle } from '@/api/articles';

export default function ArticleDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [article, setArticle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState(null);

  useEffect(() => {
    getArticle(id)
      .then(setArticle)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="loading-center"><span className="spinner spinner-lg" /></div>;
  if (error)   return <div className="alert alert-error">{error}</div>;
  if (!article) return null;

  const date = article.createdAt
    ? new Date(article.createdAt).toLocaleDateString('en-US', { dateStyle: 'long' })
    : '';

  return (
    <div>
      <div style={{ marginBottom: '1.25rem' }}>
        <Link to="/articles" className="btn btn-ghost btn-sm">← Back to articles</Link>
      </div>

      <article className="card">
        <div style={{ display: 'flex', gap: '.75rem', alignItems: 'center', marginBottom: '.5rem', flexWrap: 'wrap' }}>
          <span className={`badge ${article.status ? 'badge-published' : 'badge-draft'}`}>
            {article.status ? 'Published' : 'Draft'}
          </span>
          <span style={{ fontSize: '.8rem', color: 'var(--c-muted)' }}>ID #{article.id}</span>
        </div>

        <h1 style={{ fontSize: '1.6rem', fontWeight: 700, marginBottom: '.5rem' }}>{article.title}</h1>

        <p style={{ fontSize: '.875rem', color: 'var(--c-muted)', marginBottom: '1.25rem' }}>
          By {article.author} · {date}
        </p>

        {article.summary && (
          <p style={{ fontSize: '1rem', fontStyle: 'italic', color: 'var(--c-muted)', borderLeft: '3px solid var(--c-border)', paddingLeft: '.75rem', marginBottom: '1.25rem' }}>
            {article.summary}
          </p>
        )}

        <div
          className="article-detail__body"
          dangerouslySetInnerHTML={{ __html: article.body || '<em>No content.</em>' }}
        />

        <div style={{ marginTop: '1.75rem', paddingTop: '1rem', borderTop: '1px solid var(--c-border)' }}>
          <button className="btn btn-ghost btn-sm" onClick={() => navigate('/articles')}>
            ← All articles
          </button>
        </div>
      </article>
    </div>
  );
}
