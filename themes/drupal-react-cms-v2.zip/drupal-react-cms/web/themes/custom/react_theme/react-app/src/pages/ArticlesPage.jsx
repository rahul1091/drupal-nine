/**
 * ArticlesPage.jsx
 *
 * Main CRUD dashboard: list, create, edit, and delete Articles.
 */
import React, { useEffect, useState, useCallback } from 'react';
import { useArticles }     from '@/hooks/useArticles';
import { createArticle, updateArticle } from '@/api/articles';
import ArticleCard    from '@/components/ArticleCard';
import ArticleForm    from '@/components/ArticleForm';
import Modal          from '@/components/Modal';
import ConfirmDialog  from '@/components/ConfirmDialog';
import Pagination     from '@/components/Pagination';

export default function ArticlesPage() {
  const { articles, meta, loading, error, fetchArticles, removeArticle } = useArticles(10);

  // Modal states
  const [createOpen,  setCreateOpen]  = useState(false);
  const [editTarget,  setEditTarget]  = useState(null);  // article being edited
  const [deleteTarget, setDeleteTarget] = useState(null); // article to confirm-delete

  // Submission states
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);
  const [successMsg, setSuccessMsg] = useState('');

  const [currentPage, setCurrentPage] = useState(0);

  useEffect(() => { fetchArticles(currentPage); }, [currentPage]);

  const flash = (msg) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(''), 3500);
  };

  // --- CREATE ---
  const handleCreate = useCallback(async (payload) => {
    setSubmitting(true);
    setSubmitError(null);
    try {
      await createArticle(payload);
      setCreateOpen(false);
      await fetchArticles(currentPage);
      flash('Article created successfully.');
    } catch (err) {
      setSubmitError(err.message);
    } finally {
      setSubmitting(false);
    }
  }, [currentPage, fetchArticles]);

  // --- EDIT ---
  const handleEdit = useCallback(async (payload) => {
    setSubmitting(true);
    setSubmitError(null);
    try {
      await updateArticle(editTarget.id, payload);
      setEditTarget(null);
      await fetchArticles(currentPage);
      flash('Article updated.');
    } catch (err) {
      setSubmitError(err.message);
    } finally {
      setSubmitting(false);
    }
  }, [editTarget, currentPage, fetchArticles]);

  // --- DELETE ---
  const handleDelete = useCallback(async () => {
    setSubmitting(true);
    setSubmitError(null);
    try {
      await removeArticle(deleteTarget.id);
      setDeleteTarget(null);
      flash('Article deleted.');
    } catch (err) {
      setSubmitError(err.message);
    } finally {
      setSubmitting(false);
    }
  }, [deleteTarget, removeArticle]);

  return (
    <div>
      {/* Page header */}
      <div className="page-header">
        <h1>Articles</h1>
        <button className="btn btn-primary" onClick={() => { setSubmitError(null); setCreateOpen(true); }}>
          + New article
        </button>
      </div>

      {/* Flash messages */}
      {successMsg  && <div className="alert alert-success">{successMsg}</div>}
      {submitError && <div className="alert alert-error">{submitError}</div>}
      {error       && <div className="alert alert-error">{error}</div>}

      {/* List */}
      {loading ? (
        <div className="loading-center"><span className="spinner spinner-lg" /></div>
      ) : articles.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state__icon">📄</div>
          <h2>No articles yet</h2>
          <p>Click <strong>+ New article</strong> to create your first one.</p>
        </div>
      ) : (
        <div className="article-list">
          {articles.map((article) => (
            <ArticleCard
              key={article.id}
              article={article}
              onEdit={(a) => { setSubmitError(null); setEditTarget(a); }}
              onDelete={(a) => { setSubmitError(null); setDeleteTarget(a); }}
            />
          ))}
        </div>
      )}

      <Pagination meta={meta} onPageChange={(p) => setCurrentPage(p)} />

      {/* Create modal */}
      {createOpen && (
        <Modal title="Create article" onClose={() => setCreateOpen(false)}>
          {submitError && <div className="alert alert-error">{submitError}</div>}
          <ArticleForm
            onSubmit={handleCreate}
            onCancel={() => setCreateOpen(false)}
            isLoading={submitting}
          />
        </Modal>
      )}

      {/* Edit modal */}
      {editTarget && (
        <Modal title={`Edit: ${editTarget.title}`} onClose={() => setEditTarget(null)}>
          {submitError && <div className="alert alert-error">{submitError}</div>}
          <ArticleForm
            initialValues={editTarget}
            onSubmit={handleEdit}
            onCancel={() => setEditTarget(null)}
            isLoading={submitting}
          />
        </Modal>
      )}

      {/* Delete confirmation */}
      {deleteTarget && (
        <ConfirmDialog
          title="Delete article?"
          message={`"${deleteTarget.title}" will be permanently deleted. This cannot be undone.`}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
          isLoading={submitting}
        />
      )}
    </div>
  );
}
