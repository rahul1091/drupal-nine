import React from 'react';
import Modal from './Modal';

export default function ConfirmDialog({ title = 'Are you sure?', message, onConfirm, onCancel, isLoading }) {
  return (
    <Modal title={title} onClose={onCancel}>
      <p className="confirm-text">{message}</p>
      <div className="modal__footer">
        <button className="btn btn-ghost" onClick={onCancel} disabled={isLoading}>Cancel</button>
        <button className="btn btn-danger" onClick={onConfirm} disabled={isLoading}>
          {isLoading ? <span className="spinner" /> : null}
          Delete
        </button>
      </div>
    </Modal>
  );
}
