import React from 'react';

export default function Pagination({ meta, onPageChange }) {
  if (!meta || meta.pages <= 1) return null;

  const { page, pages, total } = meta;
  const from = page * (total / pages <= 1 ? total : Math.ceil(total / pages)) + 1;

  return (
    <div className="pagination">
      <button
        className="pagination__btn"
        disabled={page === 0}
        onClick={() => onPageChange(page - 1)}
      >← Prev</button>

      {Array.from({ length: pages }, (_, i) => (
        <button
          key={i}
          className={`pagination__btn${i === page ? ' active' : ''}`}
          onClick={() => onPageChange(i)}
        >{i + 1}</button>
      ))}

      <button
        className="pagination__btn"
        disabled={page >= pages - 1}
        onClick={() => onPageChange(page + 1)}
      >Next →</button>

      <span className="pagination__info">{total} total</span>
    </div>
  );
}
