/**
 * ArticleForm.jsx
 *
 * Shared form for creating and editing an Article.
 * Props:
 *   initialValues  – pre-fills the form when editing
 *   onSubmit(data) – async callback; receives the form payload
 *   onCancel()     – called when user clicks Cancel
 *   isLoading      – shows spinner on the submit button
 */
import React, { useState } from 'react';

const EMPTY = { title: '', body: '', summary: '', status: 1 };

export default function ArticleForm({ initialValues = EMPTY, onSubmit, onCancel, isLoading }) {
  const [values, setValues] = useState({ ...EMPTY, ...initialValues });
  const [errors, setErrors] = useState({});

  const set = (field) => (e) => {
    const val = e.target.type === 'checkbox' ? (e.target.checked ? 1 : 0) : e.target.value;
    setValues((v) => ({ ...v, [field]: val }));
    if (errors[field]) setErrors((e) => ({ ...e, [field]: '' }));
  };

  const validate = () => {
    const next = {};
    if (!values.title.trim()) next.title = 'Title is required.';
    if (values.title.length > 255) next.title = 'Title must be under 255 characters.';
    return next;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const next = validate();
    if (Object.keys(next).length) { setErrors(next); return; }
    await onSubmit(values);
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      {/* Title */}
      <div className="form-group">
        <label className="form-label" htmlFor="art-title">
          Title <span style={{ color: 'var(--c-danger)' }}>*</span>
        </label>
        <input
          id="art-title"
          type="text"
          className="form-input"
          value={values.title}
          onChange={set('title')}
          placeholder="Enter article title"
          maxLength={255}
        />
        {errors.title && <span className="form-error">{errors.title}</span>}
      </div>

      {/* Summary */}
      <div className="form-group">
        <label className="form-label" htmlFor="art-summary">Summary</label>
        <input
          id="art-summary"
          type="text"
          className="form-input"
          value={values.summary}
          onChange={set('summary')}
          placeholder="Short teaser shown in listings (optional)"
        />
      </div>

      {/* Body */}
      <div className="form-group">
        <label className="form-label" htmlFor="art-body">Body</label>
        <textarea
          id="art-body"
          className="form-textarea"
          value={values.body}
          onChange={set('body')}
          placeholder="Write the article content here…"
          rows={8}
        />
      </div>

      {/* Published toggle */}
      <div className="form-group" style={{ flexDirection: 'row', alignItems: 'center', gap: '.6rem' }}>
        <input
          id="art-status"
          type="checkbox"
          checked={!!values.status}
          onChange={set('status')}
          style={{ width: 16, height: 16, cursor: 'pointer' }}
        />
        <label htmlFor="art-status" className="form-label" style={{ margin: 0, cursor: 'pointer' }}>
          Published
        </label>
      </div>

      {/* Actions */}
      <div className="modal__footer">
        <button type="button" className="btn btn-ghost" onClick={onCancel} disabled={isLoading}>
          Cancel
        </button>
        <button type="submit" className="btn btn-primary" disabled={isLoading}>
          {isLoading ? <span className="spinner" /> : null}
          {initialValues.title ? 'Save changes' : 'Create article'}
        </button>
      </div>
    </form>
  );
}
