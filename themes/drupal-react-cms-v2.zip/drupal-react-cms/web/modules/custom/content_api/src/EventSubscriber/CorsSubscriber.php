<?php

namespace Drupal\content_api\EventSubscriber;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\HttpFoundation\Response;

/**
 * Adds CORS headers to /api/* responses.
 *
 * In production, restrict ALLOWED_ORIGINS to your actual frontend domain.
 */
class CorsSubscriber implements EventSubscriberInterface {

  /**
   * Allowed origins. Adjust for your environment.
   */
  private const ALLOWED_ORIGINS = [
    'http://localhost:5173',  // Vite dev server
    'http://localhost:3000',  // CRA dev server
    'http://localhost:8888',  // Drupal dev
  ];

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents(): array {
    return [
      KernelEvents::REQUEST  => ['onKernelRequest', 200],
      KernelEvents::RESPONSE => ['onKernelResponse', 200],
    ];
  }

  /**
   * Returns TRUE if the path falls under /api/.
   */
  private function isApiPath(string $path): bool {
    return str_starts_with($path, '/api/');
  }

  /**
   * Handle preflight OPTIONS requests immediately.
   */
  public function onKernelRequest(RequestEvent $event): void {
    $request = $event->getRequest();

    if (!$this->isApiPath($request->getPathInfo())) {
      return;
    }

    if ($request->getMethod() !== 'OPTIONS') {
      return;
    }

    $response = new Response('', 204);
    $this->addCorsHeaders($request->headers->get('Origin', ''), $response);
    $event->setResponse($response);
  }

  /**
   * Attach CORS headers to all /api/* responses.
   */
  public function onKernelResponse(ResponseEvent $event): void {
    $request = $event->getRequest();

    if (!$this->isApiPath($request->getPathInfo())) {
      return;
    }

    $this->addCorsHeaders(
      $request->headers->get('Origin', ''),
      $event->getResponse()
    );
  }

  /**
   * Writes the CORS headers onto a response.
   */
  private function addCorsHeaders(string $origin, Response $response): void {
    if (in_array($origin, self::ALLOWED_ORIGINS, TRUE)) {
      $response->headers->set('Access-Control-Allow-Origin', $origin);
    }

    $response->headers->set('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE, OPTIONS');
    $response->headers->set('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-CSRF-Token');
    $response->headers->set('Access-Control-Allow-Credentials', 'true');
    $response->headers->set('Access-Control-Max-Age', '86400');
  }

}
