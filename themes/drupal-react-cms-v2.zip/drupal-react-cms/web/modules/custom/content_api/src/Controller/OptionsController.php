<?php

namespace Drupal\content_api\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\Response;

/**
 * Returns an empty 204 for OPTIONS preflight requests.
 *
 * The CorsSubscriber event subscriber adds the actual CORS headers.
 * This controller exists only so the router resolves OPTIONS routes
 * without triggering access checks or format negotiation.
 */
class OptionsController extends ControllerBase {

  public function handle(): Response {
    return new Response('', 204);
  }

}
