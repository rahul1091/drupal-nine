<?php

namespace Drupal\content_api\Plugin\rest\resource;

use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\ResourceResponse;
use Drupal\rest\ModifiedResourceResponse;
use Drupal\node\Entity\Node;
use Drupal\Core\Session\AccountProxyInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\UnprocessableEntityHttpException;

/**
 * REST Resource for the Article content type.
 *
 * Endpoints (all require ?_format=json):
 *   GET    /api/articles                → list published articles (public)
 *   GET    /api/articles/{id}           → single article (public)
 *   POST   /api/articles                → create (authenticated)
 *   PATCH  /api/articles/{id}           → update (authenticated, own or admin)
 *   DELETE /api/articles/{id}           → delete (authenticated, own or admin)
 *
 * @RestResource(
 *   id = "content_api_articles",
 *   label = @Translation("Content API: Articles"),
 *   uri_paths = {
 *     "canonical" = "/api/articles/{id}",
 *     "create"    = "/api/articles"
 *   }
 * )
 */
class ArticlesResource extends ResourceBase {

  /**
   * The current user.
   */
  protected AccountProxyInterface $currentUser;

  /**
   * {@inheritdoc}
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    array $serializer_formats,
    LoggerInterface $logger,
    AccountProxyInterface $current_user
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $serializer_formats, $logger);
    $this->currentUser = $current_user;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->getParameter('serializer.formats'),
      $container->get('logger.factory')->get('content_api'),
      $container->get('current_user')
    );
  }

  // ---------------------------------------------------------------------------
  // GET  /api/articles          (list)
  // GET  /api/articles/{id}     (single)
  // ---------------------------------------------------------------------------

  /**
   * Responds to GET requests.
   *
   * When $id is provided responds with a single Article; otherwise returns
   * a paginated collection.  Both are publicly accessible.
   *
   * Query params for the collection:
   *   page  (int, default 0)  – zero-based page number
   *   limit (int, default 10) – items per page, max 50
   */
  public function get(Request $request, ?int $id = NULL): ResourceResponse {
    if ($id !== NULL) {
      return $this->getSingle($id);
    }
    return $this->getCollection($request);
  }

  private function getSingle(int $id): ResourceResponse {
    $node = $this->loadArticle($id);
    $response = new ResourceResponse(['data' => $this->serialize($node)], 200);
    $response->addCacheableDependency($node);
    return $response;
  }

  private function getCollection(Request $request): ResourceResponse {
    $page  = max(0, (int) $request->query->get('page', 0));
    $limit = min(50, max(1, (int) $request->query->get('limit', 10)));

    $base = \Drupal::entityQuery('node')
      ->condition('type', 'article')
      ->condition('status', 1)
      ->accessCheck(TRUE);

    $total = (clone $base)->count()->execute();

    $nids  = (clone $base)
      ->sort('created', 'DESC')
      ->range($page * $limit, $limit)
      ->execute();

    $nodes = Node::loadMultiple($nids);
    $data  = array_values(array_map([$this, 'serialize'], $nodes));

    $response = new ResourceResponse([
      'data' => $data,
      'meta' => [
        'total' => (int) $total,
        'page'  => $page,
        'limit' => $limit,
        'pages' => (int) ceil($total / $limit),
      ],
    ], 200);

    // Make the collection response vary on query string and user.
    $response->getCacheableMetadata()
      ->addCacheContexts(['url.query_args', 'user.roles:anonymous']);

    return $response;
  }

  // ---------------------------------------------------------------------------
  // POST  /api/articles
  // ---------------------------------------------------------------------------

  /**
   * Responds to POST requests – creates a new Article.
   *
   * Requires authentication. Request body (JSON):
   * {
   *   "title":   "string" (required),
   *   "body":    "string",
   *   "summary": "string",
   *   "status":  1|0  (default 1)
   * }
   */
  public function post(array $data): ModifiedResourceResponse {
    if ($this->currentUser->isAnonymous()) {
      throw new AccessDeniedHttpException('Authentication required to create articles.');
    }
    if (!$this->currentUser->hasPermission('create article content')) {
      throw new AccessDeniedHttpException('You do not have permission to create articles.');
    }

    $this->requireField($data, 'title');

    $node = Node::create([
      'type'   => 'article',
      'title'  => $this->clean($data['title']),
      'body'   => [
        'value'   => $data['body']    ?? '',
        'summary' => $data['summary'] ?? '',
        'format'  => 'basic_html',
      ],
      'status' => isset($data['status']) ? (int) $data['status'] : 1,
      'uid'    => $this->currentUser->id(),
    ]);
    $node->save();

    $this->logger->notice('Article @id created via REST.', ['@id' => $node->id()]);

    return new ModifiedResourceResponse(
      ['data' => $this->serialize($node), 'message' => 'Article created.'],
      201
    );
  }

  // ---------------------------------------------------------------------------
  // PATCH  /api/articles/{id}
  // ---------------------------------------------------------------------------

  /**
   * Responds to PATCH requests – partial update of an Article.
   *
   * Requires authentication. Only fields present in the body are updated.
   */
  public function patch(array $data, int $id): ModifiedResourceResponse {
    if ($this->currentUser->isAnonymous()) {
      throw new AccessDeniedHttpException('Authentication required.');
    }

    $node = $this->loadArticle($id);

    if (!$node->access('update', $this->currentUser)) {
      throw new AccessDeniedHttpException('You do not have permission to edit this article.');
    }

    if (isset($data['title'])) {
      $node->setTitle($this->clean($data['title']));
    }
    if (array_key_exists('body', $data) || array_key_exists('summary', $data)) {
      $current = $node->get('body')->first()?->getValue() ?? [];
      $node->set('body', [
        'value'   => $data['body']    ?? ($current['value']   ?? ''),
        'summary' => $data['summary'] ?? ($current['summary'] ?? ''),
        'format'  => 'basic_html',
      ]);
    }
    if (isset($data['status'])) {
      $node->setPublished((bool) $data['status']);
    }

    $node->save();
    $this->logger->notice('Article @id updated via REST.', ['@id' => $node->id()]);

    return new ModifiedResourceResponse(
      ['data' => $this->serialize($node), 'message' => 'Article updated.'],
      200
    );
  }

  // ---------------------------------------------------------------------------
  // DELETE  /api/articles/{id}
  // ---------------------------------------------------------------------------

  /**
   * Responds to DELETE requests.
   *
   * Requires authentication. Returns 204 No Content on success.
   */
  public function delete(int $id): ModifiedResourceResponse {
    if ($this->currentUser->isAnonymous()) {
      throw new AccessDeniedHttpException('Authentication required.');
    }

    $node = $this->loadArticle($id);

    if (!$node->access('delete', $this->currentUser)) {
      throw new AccessDeniedHttpException('You do not have permission to delete this article.');
    }

    $node->delete();
    $this->logger->notice('Article @id deleted via REST.', ['@id' => $id]);

    return new ModifiedResourceResponse(NULL, 204);
  }

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  private function loadArticle(int $id): Node {
    $node = Node::load($id);
    if (!$node || $node->bundle() !== 'article') {
      throw new NotFoundHttpException("Article {$id} not found.");
    }
    if (!$node->access('view')) {
      throw new AccessDeniedHttpException('You do not have permission to view this article.');
    }
    return $node;
  }

  private function serialize(Node $node): array {
    $body    = $node->get('body')->first()?->getValue() ?? [];
    return [
      'id'        => (int) $node->id(),
      'title'     => $node->getTitle(),
      'body'      => $body['value']   ?? '',
      'summary'   => $body['summary'] ?? '',
      'status'    => (bool) $node->isPublished(),
      'author'    => $node->getOwner()->getDisplayName(),
      'authorId'  => (int) $node->getOwnerId(),
      'createdAt' => $node->getCreatedTime()  ? date('c', $node->getCreatedTime())  : NULL,
      'updatedAt' => $node->getChangedTime()  ? date('c', $node->getChangedTime())  : NULL,
      'url'       => $node->toUrl()->setAbsolute()->toString(),
    ];
  }

  private function requireField(array $data, string $field): void {
    if (empty($data[$field])) {
      throw new UnprocessableEntityHttpException("The \"{$field}\" field is required.");
    }
  }

  private function clean(string $value): string {
    return strip_tags(trim($value));
  }

}
