<?php

namespace Drupal\content_api\Plugin\rest\resource;

use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\ResourceResponse;
use Drupal\rest\ModifiedResourceResponse;
use Drupal\node\Entity\Node;
use Drupal\Core\Session\AccountProxyInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\UnprocessableEntityHttpException;

/**
 * REST Resource for the project_tracker content type.
 *
 * Access rules:
 *   GET  (list + single)       → all users, including anonymous
 *   POST / PATCH / DELETE      → authenticated users only
 *
 * Endpoints (all require ?_format=json):
 *   GET    /api/project-trackers           – list trackers (public)
 *   GET    /api/project-trackers/{id}      – single tracker (public)
 *   POST   /api/project-trackers           – create (auth required)
 *   PATCH  /api/project-trackers/{id}      – update (auth + ownership)
 *   DELETE /api/project-trackers/{id}      – delete (auth + ownership)
 *
 * Request body fields:
 *   title        string   required on POST
 *   description  string   long text
 *   status       string   open | in_progress | on_hold | completed | cancelled
 *   severity     string   low | medium | high | critical
 *   due_date     string   ISO 8601 date (YYYY-MM-DD) or null
 *
 * @RestResource(
 *   id = "content_api_project_trackers",
 *   label = @Translation("Content API: Project Trackers"),
 *   uri_paths = {
 *     "canonical" = "/api/project-trackers/{id}",
 *     "create"    = "/api/project-trackers"
 *   }
 * )
 */
class ProjectTrackersResource extends ResourceBase {

  protected AccountProxyInterface $currentUser;

  /** Allowed values for status field */
  private const STATUS_VALUES = ['open', 'in_progress', 'on_hold', 'completed', 'cancelled'];

  /** Allowed values for severity field */
  private const SEVERITY_VALUES = ['low', 'medium', 'high', 'critical'];

  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    array $serializer_formats,
    LoggerInterface $logger,
    AccountProxyInterface $current_user
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $serializer_formats, $logger);
    $this->currentUser = $current_user;
  }

  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->getParameter('serializer.formats'),
      $container->get('logger.factory')->get('content_api'),
      $container->get('current_user')
    );
  }

  // ---------------------------------------------------------------------------
  // GET  /api/project-trackers          (collection – PUBLIC)
  // GET  /api/project-trackers/{id}     (single – PUBLIC)
  // ---------------------------------------------------------------------------

  /**
   * Responds to GET requests.
   *
   * Collection query params:
   *   page     int     zero-based page number (default 0)
   *   limit    int     items per page, max 50 (default 10)
   *   status   string  filter by status value
   *   severity string  filter by severity value
   */
  public function get(Request $request, ?int $id = NULL): ResourceResponse {
    return $id !== NULL
      ? $this->getSingle($id)
      : $this->getCollection($request);
  }

  private function getSingle(int $id): ResourceResponse {
    $node = $this->loadTracker($id);
    $response = new ResourceResponse(['data' => $this->serialize($node)], 200);
    $response->addCacheableDependency($node);
    return $response;
  }

  private function getCollection(Request $request): ResourceResponse {
    $page  = max(0, (int) $request->query->get('page', 0));
    $limit = min(50, max(1, (int) $request->query->get('limit', 10)));

    $base = \Drupal::entityQuery('node')
      ->condition('type', 'project_tracker')
      ->accessCheck(FALSE);  // Public read – bypass node access

    // Optional filters
    if ($status = $request->query->get('status')) {
      $base->condition('field_pt_status', $status);
    }
    if ($severity = $request->query->get('severity')) {
      $base->condition('field_pt_severity', $severity);
    }

    $total = (clone $base)->count()->execute();

    $nids = (clone $base)
      ->sort('created', 'DESC')
      ->range($page * $limit, $limit)
      ->execute();

    $nodes = Node::loadMultiple($nids);
    $data  = array_values(array_map([$this, 'serialize'], $nodes));

    $response = new ResourceResponse([
      'data' => $data,
      'meta' => [
        'total' => (int) $total,
        'page'  => $page,
        'limit' => $limit,
        'pages' => (int) ceil(max($total, 1) / $limit),
      ],
    ], 200);

    $response->getCacheableMetadata()
      ->addCacheContexts(['url.query_args', 'user.roles:anonymous']);

    return $response;
  }

  // ---------------------------------------------------------------------------
  // POST  /api/project-trackers   (CREATE – AUTH REQUIRED)
  // ---------------------------------------------------------------------------

  /**
   * Responds to POST requests – creates a new ProjectTracker node.
   *
   * Only authenticated users may create content.
   */
  public function post(array $data): ModifiedResourceResponse {
    // ── Access check ──────────────────────────────────────────────────────────
    if ($this->currentUser->isAnonymous()) {
      throw new AccessDeniedHttpException(
        'You must be logged in to create project trackers.'
      );
    }
    if (!$this->currentUser->hasPermission('create project_tracker content')) {
      throw new AccessDeniedHttpException(
        'You do not have permission to create project trackers.'
      );
    }

    // ── Validation ────────────────────────────────────────────────────────────
    $this->requireField($data, 'title');
    $this->validateEnum($data, 'status',   self::STATUS_VALUES,   'open');
    $this->validateEnum($data, 'severity', self::SEVERITY_VALUES, 'medium');
    $this->validateDate($data, 'due_date');

    // ── Create node ───────────────────────────────────────────────────────────
    $node = Node::create([
      'type'                 => 'project_tracker',
      'title'                => $this->clean($data['title']),
      'field_pt_description' => [
        'value'  => $data['description'] ?? '',
        'format' => 'basic_html',
      ],
      'field_pt_status'      => $data['status']   ?? 'open',
      'field_pt_severity'    => $data['severity'] ?? 'medium',
      'field_pt_due_date'    => $data['due_date']  ?? NULL,
      'status'               => 1,   // always published
      'uid'                  => $this->currentUser->id(),
    ]);
    $node->save();

    $this->logger->notice('ProjectTracker @id created by user @uid.', [
      '@id'  => $node->id(),
      '@uid' => $this->currentUser->id(),
    ]);

    return new ModifiedResourceResponse(
      ['data' => $this->serialize($node), 'message' => 'Project tracker created.'],
      201
    );
  }

  // ---------------------------------------------------------------------------
  // PATCH  /api/project-trackers/{id}   (UPDATE – AUTH + OWNERSHIP)
  // ---------------------------------------------------------------------------

  /**
   * Responds to PATCH requests – partial update of a ProjectTracker node.
   *
   * Only the author or an administrator may update a tracker.
   * Only fields present in the request body are changed.
   */
  public function patch(array $data, int $id): ModifiedResourceResponse {
    if ($this->currentUser->isAnonymous()) {
      throw new AccessDeniedHttpException('Authentication required.');
    }

    $node = $this->loadTracker($id);

    if (!$node->access('update', $this->currentUser)) {
      throw new AccessDeniedHttpException(
        'You do not have permission to update this project tracker.'
      );
    }

    // Apply changes
    if (isset($data['title'])) {
      $node->setTitle($this->clean($data['title']));
    }
    if (array_key_exists('description', $data)) {
      $node->set('field_pt_description', [
        'value'  => $data['description'],
        'format' => 'basic_html',
      ]);
    }
    if (isset($data['status'])) {
      $this->validateEnum($data, 'status', self::STATUS_VALUES, 'open');
      $node->set('field_pt_status', $data['status']);
    }
    if (isset($data['severity'])) {
      $this->validateEnum($data, 'severity', self::SEVERITY_VALUES, 'medium');
      $node->set('field_pt_severity', $data['severity']);
    }
    if (array_key_exists('due_date', $data)) {
      $this->validateDate($data, 'due_date');
      $node->set('field_pt_due_date', $data['due_date'] ?: NULL);
    }

    $node->save();
    $this->logger->notice('ProjectTracker @id updated by user @uid.', [
      '@id'  => $node->id(),
      '@uid' => $this->currentUser->id(),
    ]);

    return new ModifiedResourceResponse(
      ['data' => $this->serialize($node), 'message' => 'Project tracker updated.'],
      200
    );
  }

  // ---------------------------------------------------------------------------
  // DELETE  /api/project-trackers/{id}  (DELETE – AUTH + OWNERSHIP)
  // ---------------------------------------------------------------------------

  /**
   * Responds to DELETE requests.
   *
   * Returns 204 No Content on success.
   */
  public function delete(int $id): ModifiedResourceResponse {
    if ($this->currentUser->isAnonymous()) {
      throw new AccessDeniedHttpException('Authentication required.');
    }

    $node = $this->loadTracker($id);

    if (!$node->access('delete', $this->currentUser)) {
      throw new AccessDeniedHttpException(
        'You do not have permission to delete this project tracker.'
      );
    }

    $node->delete();
    $this->logger->notice('ProjectTracker @id deleted by user @uid.', [
      '@id'  => $id,
      '@uid' => $this->currentUser->id(),
    ]);

    return new ModifiedResourceResponse(NULL, 204);
  }

  // ---------------------------------------------------------------------------
  // Serialization
  // ---------------------------------------------------------------------------

  /**
   * Converts a project_tracker Node to a plain serializable array.
   */
  private function serialize(Node $node): array {
    $desc    = $node->get('field_pt_description')->first()?->getValue() ?? [];
    $status   = $node->get('field_pt_status')->value;
    $severity = $node->get('field_pt_severity')->value;
    $dueRaw   = $node->get('field_pt_due_date')->value;

    return [
      'id'          => (int) $node->id(),
      'title'       => $node->getTitle(),
      'description' => $desc['value'] ?? '',
      'status'      => $status   ?? 'open',
      'severity'    => $severity ?? 'medium',
      'due_date'    => $dueRaw   ?? NULL,   // YYYY-MM-DD string or null
      'author'      => $node->getOwner()->getDisplayName(),
      'authorId'    => (int) $node->getOwnerId(),
      'createdAt'   => $node->getCreatedTime() ? date('c', $node->getCreatedTime()) : NULL,
      'updatedAt'   => $node->getChangedTime() ? date('c', $node->getChangedTime()) : NULL,
      'url'         => $node->toUrl()->setAbsolute()->toString(),
    ];
  }

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  private function loadTracker(int $id): Node {
    $node = Node::load($id);
    if (!$node || $node->bundle() !== 'project_tracker') {
      throw new NotFoundHttpException("Project tracker {$id} not found.");
    }
    return $node;
  }

  private function requireField(array $data, string $field): void {
    if (empty($data[$field])) {
      throw new UnprocessableEntityHttpException("The \"{$field}\" field is required.");
    }
  }

  private function validateEnum(array $data, string $field, array $allowed, string $default): void {
    if (isset($data[$field]) && !in_array($data[$field], $allowed, TRUE)) {
      $list = implode(', ', $allowed);
      throw new UnprocessableEntityHttpException(
        "Invalid \"{$field}\" value. Allowed: {$list}."
      );
    }
  }

  private function validateDate(array $data, string $field): void {
    if (!empty($data[$field])) {
      $d = \DateTime::createFromFormat('Y-m-d', $data[$field]);
      if (!$d || $d->format('Y-m-d') !== $data[$field]) {
        throw new UnprocessableEntityHttpException(
          "Invalid \"{$field}\" format. Expected YYYY-MM-DD."
        );
      }
    }
  }

  private function clean(string $value): string {
    return strip_tags(trim($value));
  }

}
